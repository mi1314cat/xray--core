#!/usr/bin/env bash
# 命令实现层。被 bin/xbd 分发调用。
# 设计要点：Xray 常驻实例与 Browser Dialer 实例**完全解耦**，
# 所有启停都只作用于自己那一个单元，绝不互相牵连。
set -euo pipefail

# ---------------------------------------------------------------------------
# 安装与初始化
# ---------------------------------------------------------------------------
cmd_install() {
  local want_start=1 vless=""
  while [ $# -gt 0 ]; do
    case "$1" in
      --no-start) want_start=0; shift ;;
      --vless) vless="${2:-}"; shift 2 ;;
      -h|--help) xbd_usage; return 0 ;;
      *) die "未知参数: $1" ;;
    esac
  done

  need_root
  xbd_check_deps
  step "环境检查"
  has_systemd || die "需要 systemd"
  ok "架构: $(uname -m)  发行版: $(. /etc/os-release 2>/dev/null; printf '%s' "$PRETTY_NAME")"
  ok "LAN IP: $(detect_lan_ip)"
  ok "浏览器: $(browser_version)"
  ok "现有服务未受影响: xray.service=$(unit_state xray.service 2>/dev/null || echo n/a) mihomo=$(unit_state mihomo.service 2>/dev/null || echo n/a)"

  step "部署到 $XBD_PREFIX"
  local dist; dist=$(xbd_dist_dir)
  if [ "$(cd "$dist" && pwd)" = "$(cd "$XBD_PREFIX" 2>/dev/null && pwd)" ]; then
    ok "已在目标目录内运行，跳过自我拷贝"
  else
    mkdir -p "$XBD_PREFIX"
    for d in lib bin config nodes runtime logs generated backup docs service scripts tools; do
      mkdir -p "$XBD_PREFIX/$d"
    done
    cp -a "$dist/lib/." "$XBD_PREFIX/lib/" 2>/dev/null || true
    cp -a "$dist/service/." "$XBD_PREFIX/service/" 2>/dev/null || true
    cp -a "$dist/scripts/." "$XBD_PREFIX/scripts/" 2>/dev/null || true
    cp -a "$dist/docs/." "$XBD_PREFIX/docs/" 2>/dev/null || true
    [ -f "$dist/VERSION" ] && cp "$dist/VERSION" "$XBD_PREFIX/VERSION"
    # CLI 入口
    install -m 0755 "$dist/bin/xbd" "$XBD_PREFIX/bin/xbd" 2>/dev/null || true
    # 脚本以 xbd-dist 为根定位 lib（见 scripts/run-*.sh）
    mkdir -p "$XBD_DIST"
    cp -a "$dist/lib/." "$XBD_LIBDIR/" 2>/dev/null || true
    cp -a "$dist/bin/." "$XBD_DIST/bin/" 2>/dev/null || true
    cp -a "$dist/VERSION" "$XBD_DIST/VERSION" 2>/dev/null || true
    ok "已拷贝项目文件"
  fi

  # 权限：显式设定，避免 umask 造成的 203/EXEC
  chmod 0755 "$XBD_SCRIPTS"/*.sh "$XBD_LIB"/*.py "$XBD_DIST/lib"/*.py 2>/dev/null || true
  chmod 0755 "$XBD_PREFIX/bin/xbd" 2>/dev/null || true

  menu_xray_ensure
  # 浏览器是可选的：缺它只是用不了依赖浏览器拨号的节点，其余功能不受影响。
  # 这里必须吞掉它的返回值 —— core.sh 开着 `set -e`，一个裸函数调用返回 1
  # 会让整个安装中断在"浏览器"这一步，后面的 systemd 单元根本没装上，
  # 结果是客户端装完了却起不来。实测踩过：RN 上就是这么变成半装状态的。
  menu_browser_ensure || dim "未装浏览器，Browser Dialer 相关节点暂不可用（可随时补装）"

  step "写入配置（幂等，不覆盖已有内容）"
  xbd_write_default_configs

  step "安装 systemd 单元"
  local u
  for u in "$XBD_U_XRAY" "$XBD_U_SHARE" "$XBD_U_CHROMIUM" "$XBD_U_PANEL" "$XBD_U_HEALTH" "$XBD_U_TIMER"; do
    install -m 0644 "$XBD_SERVICE/$u" "/etc/systemd/system/$u"
  done
  systemctl daemon-reload
  ok "已安装 5 个单元（xray-client / chromium + panel / health / timer）"

  # 清理 v1/v2 遗留单元，避免与新架构冲突
  local old
  for old in xray-browser-client.service browser-dialer-health.service browser-dialer-health.timer; do
    if [ -f "/etc/systemd/system/$old" ] && [ "$old" != "$XBD_U_HEALTH" ] && [ "$old" != "$XBD_U_TIMER" ]; then
      systemctl disable --now "$old" >/dev/null 2>&1 || true
      rm -f "/etc/systemd/system/$old"
      dim "  已移除旧单元 $old"
    fi
  done
  systemctl daemon-reload

  # 迁移旧节点文件到统一模型
  menu_migrate_nodes

  if [ -n "$vless" ]; then
    cmd_node_add "$vless" || warn "节点未导入"
  fi

  if [ ! -e "$XBD_NODES/current" ]; then
    warn "尚未选择节点，服务未启动"
    info "下一步: xbd node add \"<uri>\"   然后 xbd start"
    return 0
  fi
  if [ "$want_start" -eq 1 ]; then
    cmd_start
  else
    warn "已按 --no-start 跳过启动"
  fi
}

xbd_write_default_configs() {
  mkdir -p "$XBD_CONF"

  # 首次安装：自动挑选**未被占用**的端口。
  # 换到新环境撞端口时不用人工排查 —— 分配器会逐个探测并避开。
  if [ ! -f "$XBD_CONF/ports.env" ]; then
    local lan; lan=$(detect_lan_ip)
    local alloc; alloc=$(python3 "$XBD_LIBDIR/ports.py" allocate --lan "$lan" --json 2>/dev/null || true)
    if [ -n "$alloc" ]; then
      step "自动分配端口"
      printf '%s' "$alloc" | python3 -c '
import sys, json
d = json.load(sys.stdin)
defaults = {"PORT_NORMAL":1080,"PORT_HTTP":10808,
            "PORT_LAN_HTTP":10809,"DIALER_ADDR":18081,"PANEL_PORT":18090,"API_PORT":18085}
labels = {"PORT_NORMAL":"LAN SOCKS5",
          "PORT_HTTP":"本机 HTTP 代理","PORT_LAN_HTTP":"局域网 HTTP 代理",
          "DIALER_ADDR":"内部通道","PANEL_PORT":"面板","API_PORT":"统计 API"}
for k, label in labels.items():
    v = d.get(k)
    if v is None: continue
    if k == "DIALER_ADDR":
        v = "127.0.0.1:" + str(v)
        changed = v != ("127.0.0.1:" + str(defaults[k]))
    else:
        changed = v != defaults[k]
    print(f"  {"  " if changed else "✓ "}{label:<24} {v}" + ("   ← 默认端口被占用，已改用这个" if changed else ""))
' 2>/dev/null || true
      _XBD_ALLOC="$alloc"
    fi
  fi

  [ -f "$XBD_CONF/ports.env" ] || {
    # 用分配结果写配置
    # 显式兜底成 {}：不能写 ${VAR:-{}} —— 默认值里的 } 会被当成展开的结束符，
    # 变量已设置时会多吐一个 }，JSON 解析失败后所有端口静默变空（实测踩过）。
    [ -n "${_XBD_ALLOC:-}" ] || _XBD_ALLOC='{}'

    local _lan _pn _ph _plh _ch _pp _api
    _lan=$(printf '%s' "${_XBD_ALLOC}" | python3 -c 'import sys,json;print(json.load(sys.stdin).get("listen_addr",""))' 2>/dev/null)
    _pn=$(printf '%s' "${_XBD_ALLOC}" | python3 -c 'import sys,json;print(json.load(sys.stdin).get("PORT_NORMAL",1080))' 2>/dev/null)
    _ph=$(printf '%s' "${_XBD_ALLOC}" | python3 -c 'import sys,json;print(json.load(sys.stdin).get("PORT_HTTP",10808))' 2>/dev/null)
    _plh=$(printf '%s' "${_XBD_ALLOC}" | python3 -c 'import sys,json;print(json.load(sys.stdin).get("PORT_LAN_HTTP",10809))' 2>/dev/null)
    _ch=$(printf '%s' "${_XBD_ALLOC}" | python3 -c 'import sys,json;print(json.load(sys.stdin).get("DIALER_ADDR",18081))' 2>/dev/null)
    _pp=$(printf '%s' "${_XBD_ALLOC}" | python3 -c 'import sys,json;print(json.load(sys.stdin).get("PANEL_PORT",18090))' 2>/dev/null)
    _api=$(printf '%s' "${_XBD_ALLOC}" | python3 -c 'import sys,json;print(json.load(sys.stdin).get("API_PORT",18085))' 2>/dev/null)
    [ -n "$_lan" ] || _lan=$(detect_lan_ip)
    cat > "$XBD_CONF/ports.env" <<EOF
# 端口分配。改完执行: xbd port <类型> <值> 或直接改这里再 xbd apply && xbd restart
# 自动分配器会避开已被占用的端口；重新分配可执行 xbd ports fix
PORT_NORMAL=${_pn:-1080}
LISTEN_ADDR=${_lan}
DIALER_ADDR=127.0.0.1:${_ch:-18081}
PORT_HTTP=${_ph:-10808}
PORT_LAN_HTTP=${_plh:-10809}
EOF
    printf 'PANEL_PORT=%s\n' "${_pp:-18090}" > "$XBD_CONF/panel.port.tmp"
    printf 'API_PORT=%s\n' "${_api:-18085}" > "$XBD_CONF/api.env"
  }

  [ -f "$XBD_CONF/ports.env" ] || cat > "$XBD_CONF/ports.env" <<EOF
# 端口规划。改完执行: xbd restart
# 唯一 Xray 实例的 SOCKS5 入口 → 局域网设备 / Mihomo 连这个
PORT_NORMAL=1080
# 只绑 LAN 地址，绝不 0.0.0.0（本机 ufw 未启用，绑 0.0.0.0 等于暴露公网）
LISTEN_ADDR=$(detect_lan_ip)
# Xray ↔ Chromium 的内部通道，仅回环
DIALER_ADDR=127.0.0.1:18081
# 本机 HTTP 代理（docker / apt / curl 用）。
# 为什么单独一个端口：docker 的 HTTP_PROXY 只认 http://，不支持 socks5://。
# 只监听回环，不对外暴露。
PORT_HTTP=10808
# 局域网 HTTP 代理：设备（手机/电脑）在 WiFi 设置里填 <本机IP>:这个端口
PORT_LAN_HTTP=10809
EOF

  # 多出站默认关。写出来而不是留着空文件，是为了让用户能一眼看到这个开关
  # 存在、默认值是什么、以及怎么改 —— 一个不存在的文件和一个空文件，
  # 用户都会怀疑"是不是漏配了什么"。
  [ -f "$XBD_MULTI_ENV" ] || cat > "$XBD_MULTI_ENV" <<'EOF'
# 多出站开关
#
# off（默认）：只有当前节点进运行配置。切换节点需要重启 Xray（连接断 1-2 秒），
#               但坏掉的只是那一个节点。
# on         ：所有节点常驻一份配置，切换节点不用重启。代价是所有节点共享
#               一份配置 —— 任何一个节点构建失败，整份配置都通不过校验。
#
# 改法：xbd multi on / xbd multi off，或面板「运行概况」里的下拉框。
MULTI_OUTBOUND=off
EOF

  [ -f "$XBD_CONF/chromium.env" ] || cat > "$XBD_CONF/chromium.env" <<'EOF'
# Chromium 运行参数（Browser Dialer 的运行时依赖）
BROWSER_DIALER_ADDR=127.0.0.1:18081
# 本机以 root 运行，Chromium 在 root 下必须 --no-sandbox
CHROMIUM_EXTRA_ARGS="--no-sandbox"
# headless 已在本机验证可用；需要图形环境时改成 xvfb 并安装 xvfb
CHROMIUM_MODE=headless
CHROMIUM_DISPLAY=:99
# Chromium 的 ECH 依赖 Secure DNS（现代 Chromium 已移除相关命令行开关）
XBD_DOH=https://dns.alidns.com/dns-query
EOF

  if [ ! -f "$XBD_CONF/panel.env" ]; then
    cat > "$XBD_CONF/panel.env" <<EOF
# 面板配置。改完执行: xbd restart panel
# 127.0.0.1=仅本机 / <LAN IP>=同局域网可访问 / 0.0.0.0=暴露公网(不要)
PANEL_HOST=$(detect_lan_ip)
PANEL_PORT=18090
PANEL_TOKEN=$(openssl rand -hex 12 2>/dev/null || head -c 12 /dev/urandom | od -An -tx1 | tr -d ' \n')
EOF
    chmod 0600 "$XBD_CONF/panel.env"
  fi
}

menu_xray_ensure() {
  step "Xray 二进制"
  if [ -x "$XBD_XRAY" ]; then
    ok "已就绪: $(first_line "$XBD_XRAY" version)"
    return 0
  fi

  # 1) 系统里已有就直接复用一份（不覆盖原文件，只复制）
  local src
  for src in /usr/local/bin/xray /usr/bin/xray; do
    if [ -x "$src" ]; then
      install -m 0755 "$src" "$XBD_XRAY"
      ok "已从 $src 复制为本项目独立副本"
      return 0
    fi
  done

  # 2) 没有就下载官方版本（全新服务器的主要路径）
  info "  未找到 Xray，正在下载官方版本…"
  mkdir -p "$XBD_BIN"
  if python3 "$XBD_LIBDIR/xrayup.py" update 2>&1 | sed 's/^/  /'; then
    if [ -x "$XBD_XRAY" ]; then
      ok "Xray 安装完成: $(first_line "$XBD_XRAY" version)"
      return 0
    fi
  fi

  bad "Xray 未就绪，无法继续"
  info "  可手动下载官方二进制放到: $XBD_XRAY"
  info "  下载页: https://github.com/XTLS/Xray-core/releases"
  return 1
}

menu_browser_ensure() {
  step "浏览器"
  if BROWSER=$(detect_browser); then
    ok "已就绪: $BROWSER — $(browser_version)"
    return 0
  fi
  warn "未找到浏览器：依赖浏览器拨号的节点将不可用，其余节点不受影响"
  return 1
}

menu_migrate_nodes() {
  [ -d "$XBD_NODES" ] || return 0
  local f migrated=0
  for f in "$XBD_NODES"/node-*.json "$XBD_NODES"/current; do
    [ -e "$f" ] || continue
    [ -L "$f" ] && continue
    python3 - "$f" <<'PY' 2>/dev/null && migrated=$((migrated+1))
import json, sys, os
sys.path.insert(0, os.environ.get("XBD_LIBDIR", "/opt/xray-browser-dialer/xbd-dist/lib"))
try:
    import node as N
except ImportError:
    raise SystemExit(1)
p = sys.argv[1]
d = json.load(open(p))
if "protocol" in d and "transport" in d and d.get("raw_params") is not None:
    raise SystemExit(1)          # 已是统一模型
n = N.new_node()
n.update({k: v for k, v in d.items() if k in n and v not in (None, "")})
n["transport_raw"] = d.get("transport_raw") or d.get("transport", "tcp")
n["transport"] = N._norm_transport(n["transport_raw"])
n["port"] = int(n.get("port") or 443)
json.dump(n, open(p, "w"), ensure_ascii=False, indent=2)
PY
  done
  [ "$migrated" -gt 0 ] && ok "已迁移 $migrated 个节点到统一模型" || true
}

# ---------------------------------------------------------------------------
# 节点管理
# ---------------------------------------------------------------------------
cmd_node() {
  local sub="${1:-list}"; shift || true
  case "$sub" in
    add|import)  cmd_node_add "$@" ;;
    simple|local) cmd_node_simple "$@" ;;
    latency|ping|delay) cmd_node_latency "$@" ;;
    list|ls)     cmd_node_list "$@" ;;
    use|select)  cmd_node_use "$@" ;;
    use-as)      cmd_node_use "$@" ;;   # 刻意不 shift：cmd_node 已经 shift 过一次
    remove|rm)   cmd_node_remove "$@" ;;
    check)       cmd_node_check "$@" ;;
    browser|bd)  cmd_node_browser "$@" ;;
    probe|test)  cmd_node_probe "$@" ;;
    sub|subscription) cmd_node_subscription "$@" ;;
      sub-refresh|refresh) cmd_node_sub_refresh "$@" ;;
    import-file) cmd_node_import_file "$@" ;;
    -h|--help|"") info "用法: xbd node <add|list|use|remove|check|browser|probe|sub|sub-refresh|import-file>" ;;
    *) die "未知子命令: $sub" ;;
  esac
}

cmd_node_add() {
  local raw="${1:-}"
  # --keep-unsupported：连 Xray 内核不支持的协议也存下来（仅存档，不参与选节点）
  local keep_unsup=0
  case "$raw" in
    --keep-unsupported) keep_unsup=1; raw="${2:-}" ;;
  esac
  if printf '%s' "${*:-}" | grep -- '--keep-unsupported' >/dev/null; then keep_unsup=1; raw="${raw/--keep-unsupported/}" ; fi
  if [ "$keep_unsup" = "1" ]; then export XBD_KEEP_UNSUPPORTED=1; fi
  if [ -z "$raw" ] && [ ! -t 0 ]; then raw=$(cat); fi
  if [ -z "$raw" ]; then
    printf '请输入节点（URI / Xray JSON / Mihomo YAML，可多行、可多个）: '
    raw=$(cat)
  fi
  [ -n "$raw" ] || die "没有输入"

  # 订阅 URL：先下载再解析。第二个参数是组名，必须透传 ——
  # 漏掉的话面板上填的名字会静默失效，节点改按名字推断出一个别的组。
  if printf '%s' "$raw" | grep -E '^https?://' >/dev/null; then
    cmd_node_subscription "$raw" "${2:-}"
    return $?
  fi
  # 关键：整段交给 parse_many。
  # 之前是按行拆开逐行解析 —— 那样多行 YAML 会被拆散，
  # 一段含多个 "- name:" 的 mihomo 配置只能碰巧识别出个别字段。
  local tmp; tmp=$(mktemp)
  printf '%s' "$raw" | python3 "$XBD_LIBDIR/node.py" multi - > "$tmp" 2>/tmp/.xbd_multi_err
  if [ ! -s "$tmp" ]; then
    bad "没有解析出可用节点: $(head -1 /tmp/.xbd_multi_err 2>/dev/null)"
    rm -f "$tmp"; return 1
  fi

  local total; total=$(python3 -c 'import json,sys;print(len(json.load(open(sys.argv[1]))))' "$tmp" 2>/dev/null || echo 0)
  [ "$total" -gt 0 ] || { rm -f "$tmp"; die "没有解析出可用节点"; }

  if [ "$total" -gt 1 ]; then
    info "检测到 $total 个节点，逐个导入："
  fi

  # 导入前先分流：Batch 里可能混着 Xray 内核根本不支持的协议（tuic / ssh / 别的内核），
  # 以及重复条目（订阅里很常见）。以前会一股脑儿落盘，列表被灌满、还得自己一个个看。
  # 现在默认：不支持的跳过、重复的跳过，最后汇总一行说明跳了什么。
  local KEEP_UNSUP=0
  [ "${XBD_KEEP_UNSUPPORTED:-0}" = "1" ] && KEEP_UNSUP=1
  python3 "$XBD_LIBDIR/nodefilter.py" "$tmp" "$XBD_LIBDIR" "$KEEP_UNSUP" "$XBD_NODES" > /tmp/.xbd_kept.jsonl 2>/tmp/.xbd_skipped.err

  local count=0 idx=0 repaired=0   # repaired: 本次为"已存在的节点"补指纹的个数（也算成功）
  while IFS= read -r node_json; do
    [ -z "$node_json" ] && continue
    idx=$((idx+1))
    printf '%s' "$node_json" > /tmp/.xbd_one.json
    if [ "$total" -gt 1 ]; then
      printf '\n  [%d/%d] ' "$idx" "$total"
    fi
    cmd_node_import_file /tmp/.xbd_one.json && count=$((count+1))
  done < /tmp/.xbd_kept.jsonl

  # 汇总跳过项
  local nskip
  nskip=$(python3 -c 'import json;print(len(json.load(open("/tmp/.xbd_skipped.json"))))' 2>/dev/null || echo 0)
  if [ "${nskip:-0}" -gt 0 ]; then
    warn "已跳过 $nskip 个节点："
    python3 -c '
import json
dup = []
for rec in json.load(open("/tmp/.xbd_skipped.json")):
    name, why = rec[0], rec[1]
    path = rec[2] if len(rec) > 2 else ""
    print("    · %-36s %s" % (str(name)[:34], why))
    if path and "重复" in why:
        dup.append(path)
# 结尾必须补换行：bash 的 `while read` 会**跳过没有尾换行的最后一行**，
# 少了这个 \n，下面那个循环体一次都不会执行（实测踩过：看着对，静默不干活）。
if dup:
    open("/tmp/.xbd_dup_paths", "w").write("\n".join(dup) + "\n")
' 2>/dev/null || true
    # 重复导入时，把「已有那一份」也补一次指纹。
    # 用户的直觉是"重新导入一次应该就好了"，但去重会直接跳过该条目 ——
    # 那份没指纹的坏节点根本没人碰，于是"再次导入还是不行"（实测踩过）。
    if [ -s /tmp/.xbd_dup_paths ]; then
      local dupf
      while IFS= read -r dupf; do
        [ -n "$dupf" ] && [ -f "$dupf" ] || continue
        info "  导入的是已存在的节点，为它补证书指纹: $(basename "$dupf")"
        _xbd_autopin_cert "$dupf"
        repaired=$((repaired+1))
      done < /tmp/.xbd_dup_paths
      rm -f /tmp/.xbd_dup_paths
    fi
    info "  （想保留这些节点存档：加 --keep-unsupported）"
  fi
  rm -f /tmp/.xbd_kept.jsonl /tmp/.xbd_skipped.json /tmp/.xbd_skipped.txt

  rm -f "$tmp" /tmp/.xbd_one.json /tmp/.xbd_multi_err
  # 修好已有节点也算成功：用户"重新导入"的意图就是让它能用，
  # 这时 count=0 是正常的，不能报失败（否则面板红字、用户以为没成）。
  if [ "$count" -eq 0 ] && [ "${repaired:-0}" -gt 0 ]; then
    ok "导入的节点已存在，已为它补上证书指纹 —— 现在可以用了"
    count=1
  fi
  [ "$count" -gt 0 ] || die "没有成功导入任何节点"
  [ "$total" -gt 1 ] && { info ""; ok "共导入 $count/$total 个节点"; }
  # 必须显式 return 0：上面那条 `[ ... ] && { ...; }` 在"只导入 1 个节点"时为假，
  # 函数于是以退出码 1 结束 —— 面板把它当失败（红字），而节点其实好好地加上了。
  return 0
}

# ---------------------------------------------------------------- 简易出站
#
# 把本机 / 局域网里**别的内核**当上游用：本客户端多一个节点，选它就走那个
# socks5/http 端口出去（方向是 outbound，不是在本机再开一个 socks 端口给
# 别人连 —— 那是 PORT_NORMAL 的事）。
#
# 对齐另外两个内核的同一功能，三条防护一个都不能少（它们都是踩出来的）：
#   · 0.0.0.0 / :: 是**监听**地址，不是能连的目标 —— 用户最常填错的一项
#   · 127.0.0.1 且端口等于本机自己的入口 = 自己代理自己，必然死循环
#   · 端口上没有东西在听时先探测再问一句，并列出在听的常见端口
cmd_node_simple() {
  local proto="" host="" port="" user="" pass="" name="" batch=0
  # 非交互：xbd node simple socks 127.0.0.1 1080 [用户] [密码] [名字]
  if [ $# -ge 3 ]; then
    proto="$1"; host="$2"; port="$3"; user="${4:-}"; pass="${5:-}"; name="${6:-}"
    batch=1
  fi

  if [ -z "$proto" ]; then
    echo
    ui_title "添加简易 SOCKS / HTTP 出站"
    ui_hint "把本机或局域网里别的内核当上游（本客户端主动连出去）"
    echo
    ui_menu 1 "socks5   多数内核都有，支持 UDP"
    ui_menu 2 "http     上游只提供 HTTP 代理时用"
    ui_menu 0 "取消"
    printf '\n  请选择 [1-2，回车=1]: '
    local c; read -r c || return 0
    case "$(printf '%s' "${c:-1}" | tr -d '[:space:]')" in
      2) proto="http" ;;
      0) return 0 ;;
      *) proto="socks" ;;
    esac
  fi
  case "$proto" in
    socks|socks5|socks5h) proto="socks" ;;
    http|https)           proto="http" ;;
    *) die "类型只能是 socks 或 http（得到 $proto）" ;;
  esac
  local defport=1080
  [ "$proto" = "http" ] && defport=8080

  # 默认 127.0.0.1：面板就跑在客户端机器上，最常见的用法是链本机另一个内核
  while :; do
    if [ -z "$host" ]; then
      printf '  目标地址 (默认 127.0.0.1): '
      read -r host || return 0
      host=$(printf '%s' "$host" | tr -d '[:space:]')
      [ -n "$host" ] || host="127.0.0.1"
    fi
    if [ "$host" = "0.0.0.0" ] || [ "$host" = "::" ]; then
      # 监听地址不是连接目标 —— 放过去的话，连的是"所有网卡"这个不存在的目标
      warn "$host 是**监听**地址，不能当连接目标"
      info "本机填 127.0.0.1；局域网里别的设备填它自己的 IP"
      [ "$batch" -eq 1 ] && return 1
      host=""
      continue
    fi
    break
  done

  if [ -z "$port" ]; then
    printf '  目标端口 (默认 %s): ' "$defport"
    read -r port || return 0
    port=$(printf '%s' "$port" | tr -d '[:space:]')
    [ -n "$port" ] || port="$defport"
  fi
  case "$port" in ''|*[!0-9]*) die "端口必须是数字（得到 $port）" ;; esac
  { [ "$port" -ge 1 ] && [ "$port" -le 65535 ]; } || die "端口必须在 1-65535（得到 $port）"

  # 自己代理自己：本机入口端口就是自己，链上去必然死循环。
  # ★ 本机地址要认全：回环（127.0.0.1/localhost/::1）**以及本机自己的
  #   LAN IP** —— 实测最容易踩的就是后者：面板给了"局域网设备填 192.168.x.x"，
  #   用户在本机上照着填，指向的还是自己。
  xbd_load_ports
  local _self_ip _is_self=0
  case "$host" in
    127.0.0.1|localhost|::1) _is_self=1 ;;
    *)
      _self_ip=$(detect_lan_ip 2>/dev/null || true)
      [ -n "$_self_ip" ] && [ "$host" = "$_self_ip" ] && _is_self=1
      for _self_ip in $(hostname -I 2>/dev/null || true); do
        [ "$host" = "$_self_ip" ] && _is_self=1
      done ;;
  esac
  if [ "$_is_self" -eq 1 ]; then
    local p
    for p in $XBD_PORT_NORMAL $XBD_PORT_HTTP $XBD_PORT_LAN_HTTP; do
      [ "$port" = "$p" ] && die "$host:$port 就是本客户端自己的入口 —— 自己代理自己会死循环"
    done
  fi

  # 探测：通不通先看一眼，不通就问一句（另外两个内核也是这么做的）
  if ! _xbd_port_open "$host" "$port"; then
    warn "$host:$port 上没有东西在监听"
    local common="" p2
    for p2 in 1080 1081 7890 7891 8080 8888 10808 10809; do
      [ "$p2" = "$port" ] && continue
      _xbd_port_open "$host" "$p2" && common="$common $p2"
    done
    [ -n "$common" ] && info "这台机器上在听的口:$common"
    if [ "$batch" -eq 0 ]; then
      printf '  仍要继续? [y/N] '
      local a; read -r a || return 0
      case "$a" in y|Y) ;; *) return 0 ;; esac
    fi
  else
    ok "$host:$port 有东西在监听"
  fi

  if [ "$batch" -eq 0 ]; then
    printf '  用户名 (留空=不认证): '; read -r user || return 0
    user=$(printf '%s' "$user" | tr -d '[:space:]')
    printf '  密码 (留空=不认证): '; read -r pass || return 0
    pass=$(printf '%s' "$pass" | tr -d '[:space:]')
    if [ -n "$pass" ] && [ -z "$user" ]; then
      warn "只填了密码没填用户名，按不认证处理"
      pass=""
    fi
    printf '  节点名 (留空自动生成): '; read -r name || return 0
  fi

  local tmp
  tmp=$(mktemp)
  if ! SIMPLE_PROTO="$proto" SIMPLE_HOST="$host" SIMPLE_PORT="$port" \
       SIMPLE_USER="$user" SIMPLE_PASS="$pass" SIMPLE_NAME="$name" \
       XBD_LIBDIR="$XBD_LIBDIR" python3 - "$tmp" <<'PY'
import json, os, sys
sys.path.insert(0, os.environ.get("XBD_LIBDIR", ""))
import node as N
n = N.simple_node(os.environ["SIMPLE_PROTO"], os.environ["SIMPLE_HOST"],
                  int(os.environ["SIMPLE_PORT"]), os.environ.get("SIMPLE_USER", ""),
                  os.environ.get("SIMPLE_PASS", ""), os.environ.get("SIMPLE_NAME", ""))
json.dump(n, open(sys.argv[1], "w", encoding="utf-8"), ensure_ascii=False, indent=1)
PY
  then
    bad "生成节点失败"; rm -f "$tmp"; return 1
  fi
  _xbd_node_save_json "$tmp" || { rm -f "$tmp"; return 1; }
  rm -f "$tmp"
  info ""
  info "切换: xbd node use <编号> ｜ 列表: xbd node list"
  return 0
}

# 端口上有没有东西在听（TCP）。用 bash 的 /dev/tcp，不依赖 nc/ss 的版本差异。
_xbd_port_open() { # <host> <port>
  timeout 3 bash -c "cat < /dev/null > /dev/tcp/$1/$2" 2>/dev/null
}

# 把一份节点 JSON 落盘。与导入路径共用同一套：编号、slug、导入即固定证书、
# 首个节点自动选中。抽出来是为了"简易节点"和"粘贴链接"两条路不会漂。
_xbd_node_save_json() { # <json 文件>
  local tmp="$1" slug dest idx=1
  slug=$(python3 -c '
import json,sys,re
d=json.load(open(sys.argv[1]))
s=re.sub(r"[^A-Za-z0-9._-]+","-",(d.get("name") or d.get("address") or "node")).strip("-").lower()
print(s[:40] or "node")' "$tmp")
  while :; do
    dest="$XBD_NODES/$(printf 'node-%03d' "$idx")-$slug.json"
    [ -e "$dest" ] && { idx=$((idx+1)); continue; }
    break
  done
  _xbd_autopin_cert "$tmp"
  install -m 0644 "$tmp" "$dest"
  print_node_card "$dest"
  if [ ! -e "$XBD_NODES/current" ]; then
    ln -sfn "$(basename "$dest")" "$XBD_NODES/current"
    ok "已设为当前节点: $(basename "$dest")"
  fi
  return 0
}

cmd_node_import_one() {  # 解析一个节点并落盘；成功返回 0
  local raw="$1" tmp
  tmp=$(mktemp)
  if ! printf '%s' "$raw" | python3 "$XBD_LIBDIR/node.py" parse - > "$tmp" 2>/tmp/.xbd_node_err; then
    bad "解析失败: $(cat /tmp/.xbd_node_err 2>/dev/null | awk 'NR==1')"
    rm -f "$tmp"; return 1
  fi

  # 落盘 + 能力检查结果
  local slug dest idx=1
  slug=$(python3 -c '
import json,sys,re
d=json.load(open(sys.argv[1]))
s=re.sub(r"[^A-Za-z0-9._-]+","-",(d.get("name") or d.get("address") or "node")).strip("-").lower()
print(s[:40] or "node")' "$tmp")
  while :; do
    dest="$XBD_NODES/$(printf 'node-%03d' "$idx")-$slug.json"
    [ -e "$dest" ] && { idx=$((idx+1)); continue; }
    break
  done
  # 顺序很重要：**先在临时文件上补指纹，再落盘**。
  # 旧顺序是先 install 再补 —— 而补的过程可能要编译证书探针（冷构建实测 114 秒），
  # 面板导入动作的超时是 120 秒：一旦被杀，磁盘上就留下一个"已导入但没有指纹"的
  # 节点，界面上看是成功的，实际必然连不上（Xray 26.x 没有 allowInsecure）。
  # 现在最坏情况只是"没导入成功"，用户重试即可，不会再产生半成品。
  _xbd_autopin_cert "$tmp"    # v2.2: 导入即固定证书指纹，免除手动 xbd cert
  install -m 0644 "$tmp" "$dest"; rm -f "$tmp"

  local caps
  # 注意：compat.py 在"两种模式都不可用"时退出码为 1（这是有效结论，不是失败），
  # 所以这里不能写 || echo '{}' —— 那样会把结论丢掉。
  # 有意**不**把判定结果写进节点文件 —— 那是导入瞬间的快照，会过期。
  # 判定一律实时算（nodelist.py / state.py 都如此），避免"显示与实际能力脱节"。
  print_node_card "$dest"
  # 首个节点自动选中
  if [ ! -e "$XBD_NODES/current" ]; then
    ln -sfn "$(basename "$dest")" "$XBD_NODES/current"
    ok "已设为当前节点: $(basename "$dest")"
  fi
  return 0
}

print_node_card() {  # print_node_card <node.json>
  python3 - "$1" "$XBD_LIBDIR" <<'PY'
import importlib.util, json, os, sys
d = json.load(open(sys.argv[1]))
# 现场判定，不读文件里的 _compat 缓存（会过期）
_c = {}
try:
    spec = importlib.util.spec_from_file_location("_c", os.path.join(sys.argv[2], "compat.py"))
    _m = importlib.util.module_from_spec(spec); spec.loader.exec_module(_m)
    _c = _m.check_all(d)
except Exception:
    pass
c = _c
x = (c.get("xray") or {}).get("overall", "UNKNOWN")
b = (c.get("dialer") or {}).get("overall", "UNKNOWN")
tagmap = {"SUPPORTED": "✓ 支持", "SUPPORTED_WITH_WARNING": "⚠ 支持（有注意项）",
          "NOT_SUPPORTED": "✗ 不支持", "UNKNOWN": "? 未知"}
print()
print(f"  节点名称：{d.get('name')}")
print(f"  Xray：            {tagmap.get(x, x)}")
print(f"  Browser Dialer：  {tagmap.get(b, b)}")
tags = c.get("tags") or []
if tags:
    print("  能力标签：" + "  ".join(f"[{t}]" for t in tags))
notes = (c.get("dialer") or {}).get("notes") or []
if b not in ("SUPPORTED", "SUPPORTED_WITH_WARNING") and notes:
    print("  原因：")
    for n in notes[:3]:
        print(f"    - {n}")
# Xray 段的注意事项也要打 —— 原来只打 dialer 那段，于是 xray 段里最关键的那句
# 「该节点声明了 skip-cert-verify，需要先 xbd cert 固定指纹，否则连不上」
# 从来没显示过：卡片写着"⚠ 支持（有注意项）"却不说注意什么（实测踩过）。
if x not in ("SUPPORTED",):
    for n in ((c.get("xray") or {}).get("notes") or [])[:3]:
        print(f"    * {n}")
PY
}

import_node_file() {  # 内部：把一个文件导入为节点
  cmd_node_import_one "$(cat "$1")"
}

cmd_node_import_file() {
  local f="${1:-}"
  [ -f "$f" ] || die "文件不存在: $f"
  cmd_node_import_one "$(cat "$f")"
}

# ---------------------------------------------------------------- 三家互通
# 订阅地址上的**内核声明** → 这次拉哪一份产品。设计（字段定义 / 决策规则与
# 回退链 / 与 compat 的分工）: proxy-node-compat/docs/three-way-interop.md
#
#   同内核**同发行版** → 原生（Xray JSON, URI 装不下的字段不丢）
#   跨内核 / 声明缺失 / 声明不认识 / 发行版不在清单 → 普通话（base64 URI 列表）
#
# 决策只看**地址本身**: 不额外发请求、不看 User-Agent、不做任何协商。
# 服务端声明用的是查询串, 而公共分享服务的路由先剥查询串再分发
# （share_service.py:768）—— 所以带声明的地址对第三方客户端零影响。
_sub_interop_decide() {   # <订阅地址> → 一行 JSON（拿不到打印空串）
  python3 "$XBD_LIBDIR/interop.py" decide "$1" 2>/dev/null || true
}

_sub_interop_field() {    # <JSON> <字段>
  printf '%s' "$1" | python3 -c 'import sys, json
try: print((json.load(sys.stdin) or {}).get(sys.argv[1], "") or "")
except Exception: print("")' "$2" 2>/dev/null || true
}

# 拉一个地址并解析成节点列表。打印**节点数**（失败 0）; 结果写进 $2。
# 永远返回 0: 调用方按"节点数"判断, 不靠退出码 —— 本文件是 `set -e`,
# 让 helper 带非 0 退出会在赋值处直接把整个命令打断。
_sub_fetch_nodes() {      # <地址> <输出json文件>
  local url="$1" out="$2" body=""
  : > "$out"
  body=$(curl -sL --max-time 60 "$url" 2>/dev/null) || body=""
  [ -n "$body" ] || { printf '0'; return 0; }
  printf '%s' "$body" | python3 "$XBD_LIBDIR/node.py" subscription - > "$out" 2>/dev/null || true
  python3 -c 'import json,sys
try: print(len(json.load(open(sys.argv[1]))))
except Exception: print(0)' "$out" 2>/dev/null || printf '0'
}

# 按声明取产品 → 解析。打印 "<模式>\t<节点数>\t<说明>", 节点写进 $2。
#   模式 = native（原生）/ uri（普通话）
# **原生取件失败自动回退普通话**, 并把原因留在说明里 —— 不许静默降级。
_sub_fetch_by_declaration() {   # <订阅地址> <输出json文件>
  local url="$1" out="$2" pick choice reason rurl detail n=0
  pick=$(_sub_interop_decide "$url")
  choice=$(_sub_interop_field "$pick" choice); [ -n "$choice" ] || choice=uri
  reason=$(_sub_interop_field "$pick" reason)
  rurl=$(_sub_interop_field "$pick" url)
  detail=$(_sub_interop_field "$pick" detail)
  if [ "$choice" = "native" ] && [ -n "$rurl" ]; then
    n=$(_sub_fetch_nodes "$rurl" "$out")
    if [ "${n:-0}" -gt 0 ] 2>/dev/null; then
      printf 'native\t%s\t%s' "$n" "$detail"
      return 0
    fi
    # 回退: 声明说原生在那边, 但那边取不到/解析不出 → 回到最通用的普通话。
    detail="${detail}；原生取件失败(${rurl}) → 回退"
    [ -n "$reason" ] || reason=native-fetch-failed
  fi
  n=$(_sub_fetch_nodes "$url" "$out")
  printf 'uri\t%s\t%s' "$n" "$detail"
  return 0
}

# 把"这次拉的是哪种"打到 stderr（用户要能一眼看出原生还是普通话）
_sub_report_choice() {    # <模式> <节点数> <说明>
  case "${1:-}" in
    native) ok "本次拉取: 原生 Xray JSON —— ${3:-}" ;;
    *)      info "本次拉取: 普通话 URI 列表 —— ${3:-}" ;;
  esac
}

cmd_node_subscription() {
  local url="${1:-}" sub_name="${2:-}"
  [ -n "$url" ] || die "用法: xbd node sub <订阅URL> [组名]"
  step "下载订阅"

  local tmp; tmp=$(mktemp)
  local line mode n detail
  line=$(_sub_fetch_by_declaration "$url" "$tmp")
  mode=$(printf '%s' "$line" | cut -f1)
  n=$(printf '%s' "$line" | cut -f2)
  detail=$(printf '%s' "$line" | cut -f3)
  [ "${n:-0}" -gt 0 ] 2>/dev/null || { rm -f "$tmp"; die "订阅里没有解析出节点"; }
  _sub_report_choice "$mode" "$n" "$detail"
  ok "解析出 $n 个节点"

  # 先记下已有哪些节点文件，后面据此判断"哪些是这次新增的"。
  # 必须先记再导：反过来记，导入过程中根本分不清新旧。
  local before; before=$(mktemp)
  ls -1 "$XBD_NODES" 2>/dev/null | grep '\.json$' > "$before" || true

  # 先注册订阅、再导入节点。顺序不能反：先导后注册的话，中途失败会留下一批
  # 没有任何归属的节点，它们下次分组只能靠名字猜，落到「其它」里找不回来了。
  local gid="" gname="" reg=""
  if [ -n "$sub_name" ]; then
    reg=$(python3 "$XBD_LIBDIR/subs.py" add "$XBD_PREFIX" "$url" "$sub_name" 2>/dev/null)
    gid=$(printf '%s' "$reg"   | python3 -c 'import json,sys;print((json.load(sys.stdin) or {}).get("id",""))'   2>/dev/null)
    gname=$(printf '%s' "$reg" | python3 -c 'import json,sys;print((json.load(sys.stdin) or {}).get("name",""))' 2>/dev/null)
  fi

  python3 - "$tmp" <<'PY' > /tmp/.xbd_sub_lines
import json, sys
for node in json.load(open(sys.argv[1])):
    print(json.dumps(node, ensure_ascii=False))
PY
  # 过滤: 去掉内核不支持的和已存在的。少了这一步, 每拉一次订阅节点就翻倍。
  _sub_keep=0
  [ "${XBD_KEEP_UNSUPPORTED:-0}" = "1" ] && _sub_keep=1
  if ! _sub_filter "$tmp" "$_sub_keep" > /tmp/.xbd_sub_kept.jsonl 2>/dev/null; then
    rm -f "$tmp" /tmp/.xbd_sub_lines
    die "节点过滤失败"
  fi
  local c=0 line
  while IFS= read -r line; do
    [ -z "$line" ] && continue
    cmd_node_import_one "$line" >/dev/null && c=$((c+1))
    done < /tmp/.xbd_sub_kept.jsonl
    rm -f "$tmp" /tmp/.xbd_sub_lines /tmp/.xbd_sub_kept.jsonl

  if [ -n "$gid" ]; then
    # 分组盖在节点文件里，不是每次现推。机场改了节点命名，现推出来的组会整个
    # 变掉，用户昨天记住的分组今天对不上。
    #
    # 比对的是"导入开始前已有的文件"，所以走的是 nodefilter 之后真正落盘的那
    # 几个 —— 被过滤掉的重复节点不会混进来。
    local bound
    bound=$(python3 "$XBD_LIBDIR/subs.py" bind-latest "$XBD_PREFIX" "$gid" \
            $(cat "$before" 2>/dev/null | tr '\n' ' ') 2>/dev/null \
            | python3 -c 'import json,sys;print((json.load(sys.stdin) or {}).get("stamped",0))' 2>/dev/null)
    ok "已导入 $c 个节点，归入分组「${gname:-$sub_name}」(${bound:-0} 个)"
  else
    ok "已导入 $c 个节点"
  fi
  rm -f "$before"
}

  # 订阅必须过 nodefilter。粘贴路径走的是它 (见 cmd_node_add), 订阅路径
  # 以前直接逐条落盘 —— 而订阅天然会重复拉取, 于是每刷新一次节点数就翻
  # 一倍, 列表被灌满。去重依据是 protocol|address|port|uuid|password|
  # transport, 与已落盘节点比对。
  _sub_filter() {   # $1=解析结果文件  $2=保留不支持项(0/1)
    python3 "$XBD_LIBDIR/nodefilter.py" "$1" "$XBD_LIBDIR" "$2" "$XBD_NODES"
  }

  # 刷新订阅: 拉取 → 去重 → 增量落盘。
  #
  # 失败时保留全部旧节点, 并且只在"拉到且解析出节点"之后才动磁盘。
  # 先删后拉的话, 一次性链接 (限 1 次) 拉废之后就再也拉不回来, 节点全灭且
  # 无法恢复 —— sing-box 与 mihomo 的更新路径都专门为此做了备份还原。
  cmd_node_sub_refresh() {
    local url="${1:-}"
    [ -n "$url" ] || die "用法: xbd node sub-refresh <订阅URL>"
    step "刷新订阅"

    # 与导入走**同一套**声明决策与回退链（_sub_fetch_by_declaration）——
    # 两处各写一遍的话, 表现会是"导入时走原生、刷新时走普通话"（或反过来）,
    # 而两边都不报错。
    local tmp; tmp=$(mktemp)
    local line mode n detail
    line=$(_sub_fetch_by_declaration "$url" "$tmp")
    mode=$(printf '%s' "$line" | cut -f1)
    n=$(printf '%s' "$line" | cut -f2)
    detail=$(printf '%s' "$line" | cut -f3)
    if [ "${n:-0}" -le 0 ] 2>/dev/null; then
      rm -f "$tmp"
      err "订阅里没有解析出节点, 保留现有节点"
      return 1
    fi
    _sub_report_choice "$mode" "$n" "$detail"
    ok "解析出 $n 个节点"

    _sub_filter "$tmp" 0 > /tmp/.xbd_ref_kept.jsonl 2>/dev/null || true
    local c=0 line
    while IFS= read -r line; do
      [ -z "$line" ] && continue
      cmd_node_import_one "$line" >/dev/null && c=$((c+1))
    done < /tmp/.xbd_ref_kept.jsonl
    rm -f "$tmp" /tmp/.xbd_ref_kept.jsonl
    ok "新增 $c 个节点 (已存在的跳过)"
    return 0
  }

cmd_node_list() {
  XBD_PREFIX="$XBD_PREFIX" python3 "$XBD_LIBDIR/nodelist.py"
}

# 解析「编号 | 文件名 | 名称」→ 节点文件路径。找不到就输出空串，由调用方报错。
#
# 为什么必须收成一个函数：这段逻辑原本被复制了 7 份（node use/browser/probe/remove/
# check/cert/use-as），而且那个写法在 set -euo pipefail 下有隐蔽的坑：
#     path=$(ls -1 "$XBD_NODES"/*"$t"* 2>/dev/null | head -1)
# 通配符不匹配时 ls 退出码 2，pipefail 让整个命令替换失败，set -e 于是**直接退出、
# 一个字都不打印**。实测：`xbd node remove HY2`（用面板显示的名称）静默退出 2，
# 用户只会以为"命令没反应"。
# 顺带支持按节点的 name 字段匹配 —— 面板显示的就是这个名字，用户自然会用它。
xbd_node_path() {
  local t="${1:-}" path=""
  [ -n "$t" ] || return 0
  if [[ "$t" =~ ^[0-9]+$ ]]; then
    path=$(ls -1 "$XBD_NODES"/node-*.json 2>/dev/null | sed -n "${t}p" || true)
  else
    [ -e "$XBD_NODES/$t" ] && path="$XBD_NODES/$t"
    [ -n "$path" ] || path=$(ls -1 "$XBD_NODES"/*"$t"* 2>/dev/null | awk 'NR==1' || true)
    [ -n "$path" ] || path=$(python3 - "$XBD_NODES" "$t" <<'PY' 2>/dev/null || true
import json, os, sys
ndir, want = sys.argv[1], sys.argv[2].strip().lower()
for f in sorted(os.listdir(ndir)):
    if not f.endswith(".json"):
        continue
    try:
        n = json.load(open(os.path.join(ndir, f)))
    except Exception:
        continue
    if (n.get("name") or "").strip().lower() == want:
        print(os.path.join(ndir, f))
        break
PY
)
  fi
  printf '%s' "${path:-}"
}

cmd_node_use() {
  local t="${1:-}" how="${2:-}"
  [ -n "$t" ] || { cmd_node_list; info ""; info "用法: xbd node use <编号|文件名> [bd|normal]"; return 0; }
  local path
  if [[ "$t" =~ ^[0-9]+$ ]]; then
    path=$(xbd_node_path "$t")
    [ -n "$path" ] || die "没有编号 $t 的节点"
  else
    path=$(xbd_node_path "$t")
    [ -e "${path:-}" ] || die "找不到节点: $t"
  fi
  ln -sfn "$(basename "$path")" "$XBD_NODES/current"
  ok "当前节点 → $(basename "$path")"
  print_node_card "$path"

  # 明确指定用法时（面板的「普通连接」/「BD 连接」按钮走这里），把选择写进节点文件。
  # 这样"点按钮"就是用户意图的完整表达，不需要他再去理解环境变量那一层。
  case "$how" in
    bd|browser)   _xbd_set_node_browser "$path" true  ;;
    normal|native) _xbd_set_node_browser "$path" false ;;
    "") : ;;
    *) die "未知用法: $how（可选 bd / normal）" ;;
  esac

  # 按**新节点自己**的实际情况让 Chromium 状态跟上。
  #
  # ⚠ 判据必须与 run-xray.sh 完全一致（都用 compat.py want-bd）：
  #   want = 该节点**会不会**用浏览器（含用户的 use_browser 选择）
  # 只有 want 为真、但进程还没带 XRAY_BROWSER_DIALER 时，才需要重启一次 ——
  # 因为"带不带这个环境变量"是进程启动时决定的。
  # 以前这里用"协议层面是否可能"来判断要不要保留 Chromium，结果用户点了
  # 「普通连接」（明确要原生）也被拒绝关闭 —— 那是把保护做成了妨碍。
  local want=no
  _xbd_node_needs_dialer && want=yes

  if [ "$want" = "yes" ]; then
    if ! unit_active "$XBD_U_CHROMIUM"; then
      warn "该节点使用浏览器完成 TLS，正在启动 Chromium"
      xbd_dialer_on || warn "自动启动失败，可手动执行: xbd dialer on"
    fi
  else
    if unit_active "$XBD_U_CHROMIUM"; then
      warn "该节点不用浏览器，正在停掉 Chromium 释放内存"
      xbd_dialer_off || true
    fi
  fi

  # ⚠ 换了节点就**必须**重启，否则运行中的实例还在用旧节点。
  #
  # 这里原来只打印一句"执行 xbd apply && xbd restart 生效"，把动作留给用户 ——
  # 实测踩过：从 hysteria 节点切到另一个 hysteria 节点，浏览器开关没变，
  # 于是既不重启也不报错，**界面上节点已经换好了、实际流量还走旧节点**
  # （排查时看到进程启动时间比切换时间还早才发现）。
  # 判据是**配置文件有没有变**，不是"软链接是不是刚被改动" ——
  # 后者漏过一次：上一次 node use 只改了软链接、没重启，这一次 prev 与它相同，
  # 于是又跳过重启，运行中的实例继续用旧节点（实测踩过）。
  # 重新生成一次再比对哈希，是唯一可靠的"运行态 != 期望态"判据。
  local cfg="$XBD_RUNTIME/xray-client.json" before after
  before="$(sha256sum "$cfg" 2>/dev/null | cut -d' ' -f1)"
  cmd_apply >/dev/null 2>&1 || warn "配置生成失败，请手动执行: xbd apply"
  after="$(sha256sum "$cfg" 2>/dev/null | cut -d' ' -f1)"
  if unit_active "$XBD_U_XRAY"; then
    if [ "$before" != "$after" ]; then
      info "节点配置已变化，重启 Xray 生效…"
      _xbd_sync_xray_with_node force || warn "Xray 重启失败，请手动执行: xbd restart"
    else
      _xbd_sync_xray_with_node || warn "Xray 重启失败，请手动执行: xbd restart"
    fi
  fi
}

# 每个节点自己的"是否用浏览器完成 TLS"开关。
# 为什么不放在全局：全局一关，所有依赖浏览器的节点一起失效（实测踩过）；
# 而用户往往只是想给某一个节点省下那 ~890MB 内存。
cmd_node_browser() {
  local t="${1:-}" v="${2:-}"
  [ -n "$t" ] || die "用法: xbd node browser <编号|文件名> <on|off|auto>"
  local path
  if [[ "$t" =~ ^[0-9]+$ ]]; then
    path=$(xbd_node_path "$t")
    [ -n "$path" ] || die "没有编号 $t 的节点"
  else
    path=$(xbd_node_path "$t")
    [ -e "${path:-}" ] || die "找不到节点: $t"
  fi
  [ -n "$v" ] || die "用法: xbd node browser <编号|文件名> <on|off|auto>"

  # 协议不支持时不允许打开 —— 置灰的后端对应物，别让界面骗人
  local can
  can=$(python3 "$XBD_LIBDIR/compat.py" json "$path" 2>/dev/null \
        | python3 -c 'import sys,json;print(json.load(sys.stdin).get("can_use_dialer"))' 2>/dev/null || echo False)

  # 这里**允许**对任何节点关闭（包括 xhttp/websocket）。
  # 曾经禁止过，理由是"只要 XRAY_BROWSER_DIALER 在线，xhttp/ws 出站就会被强制接管，
  # 关掉会让节点不可用"—— 那个推理没错，但解决方式错了：
  # 正确的做法是关闭时**同时让这个 Xray 进程不再声明该能力**（见 scripts/run-xray.sh，
  # 它按当前节点的开关决定带不带 XRAY_BROWSER_DIALER）。
  # 这样关掉之后节点自动走原生 TLS，既省下 Chromium 的内存，也不需要用户理解这些。
  # 之前的做法等于"因为实现有缺陷，就不让用户关"。
  if [ "$can" = "True" ] && [ "$v" = "off" ]; then
    # 协议支持 != 关掉之后还能用。
    #
    # 有些服务端就是靠"客户端用浏览器完成 TLS"才有活路 —— 常见于套了 CDN,
    # 或专门对浏览器指纹做校验的。这类节点一旦切到 Xray 自带 TLS,
    # 指纹对不上, 直接连不通。
    #
    # CC 实测: node-001-ccsmvless-01 (xhttp+tls) 开着浏览器 SOCKS 返回 204,
    # 一关就变 000; 直接用 curl 原生 TLS 连它服务端, 连根路径都是 000。
    #
    # 所以这里不能无脑放行。能不能关让用户自己定, 但必须把后果说清楚 ——
    # 之前这里只 info 一句"不影响可用性", 在这个场景下是错的:
    # 用户照着关, 节点就废了, 而提示还说了没事。
    warn "关掉后该节点改用 Xray 自带 TLS"
    info "但有些服务端只认浏览器的 TLS 指纹, 关掉就可能连不通。"
    printf '  要继续关闭吗? [y/N]: '
    local go; read -r go || return 1
    case "$go" in
      y|Y|yes|YES) ;;
      *) info "已取消"; return 0 ;;
    esac
  fi

  if [ "$can" != "True" ] && [ "$v" != "off" ] && [ "$v" != "auto" ]; then
    bad "该节点的协议不支持浏览器拨号（只有 xhttp/websocket 且非 REALITY 可以）"
    info "它仍然可以正常使用 Xray 自带 TLS：同一个入口，无需任何设置"
    return 1
  fi

  case "$v" in
    on)   _xbd_set_node_browser "$path" true  ;;
    off)  _xbd_set_node_browser "$path" false ;;
    auto) _xbd_set_node_browser "$path" null  ;;
    *) die "未知取值: $v（可选 on/off/auto）" ;;
  esac

  # 改的就是当前节点 -> 立刻生效。
  # ⚠ 必须重启 Xray：是否带 XRAY_BROWSER_DIALER 是**进程启动时**决定的，
  # 光改节点文件不重启，进程仍会走旧的那条路（这是"关不掉"的第二个原因）。
  if [ "$(readlink -f "$XBD_NODES/current" 2>/dev/null)" = "$(readlink -f "$path")" ]; then
    local want="no"
    _xbd_node_needs_dialer && want="yes"
    info "正在重启 Xray 让设置生效…"
    systemctl restart "$XBD_U_XRAY" 2>/dev/null || true
    sleep 4
    unit_active "$XBD_U_XRAY" || { bad "Xray 重启失败"; journalctl -u "$XBD_U_XRAY" -n 10 --no-pager; return 1; }
    if [ "$want" = "yes" ]; then
      unit_active "$XBD_U_CHROMIUM" || { info "该节点要用浏览器，正在启动 Chromium"; xbd_dialer_on || true; }
      ok "已生效：该节点走浏览器 TLS"
    else
      unit_active "$XBD_U_CHROMIUM" && { info "该节点不用浏览器了，正在停掉 Chromium 释放内存"; xbd_dialer_off || true; }
      ok "已生效：该节点走 Xray 自带 TLS"
    fi
  else
    ok "已保存。切到该节点时按此生效"
  fi
}

_xbd_set_node_browser() {
  python3 - "$1" "$2" <<'PYEOF'
import json, sys
path, val = sys.argv[1], sys.argv[2]
d = json.load(open(path))
d["use_browser"] = None if val == "null" else (val == "true")
json.dump(d, open(path, "w"), ensure_ascii=False, indent=2)
PYEOF
}

# 真实探测：这个节点走浏览器路径到底通不通。
# 能力判定只能验证"配置合法"，合法不等于能通（实测：同一套 ws 配置，
# 有的服务器可用、有的不行）。所以给一个能跑的探测，结果写回节点文件。
cmd_node_probe() {
  local t="${1:-}" all=0
  [ "$t" = "--all" ] && { all=1; t=""; }
  need_root
  local targets=()
  if [ "$all" = 1 ]; then
    local f
    for f in "$XBD_NODES"/node-*.json; do [ -e "$f" ] && targets+=("$f"); done
  else
    [ -n "$t" ] || { cmd_node_list; info ""; info "用法: xbd node probe <编号|文件名> | xbd node probe --all"; return 0; }
    local path
    if [[ "$t" =~ ^[0-9]+$ ]]; then
      path=$(xbd_node_path "$t")
      [ -n "$path" ] || die "没有编号 $t 的节点"
    else
      path=$(xbd_node_path "$t")
      [ -e "${path:-}" ] || die "找不到节点: $t"
    fi
    targets=("$path")
  fi

  step "浏览器路径实测探测（会临时起一个 Xray + Chromium，不动生产服务）"
  local f ok=0 bad=0 skip=0
  for f in "${targets[@]}"; do
    printf '  %-34s ' "$(python3 -c "import json;print(str(json.load(open('$f')).get('name'))[:32])" 2>/dev/null)"
    local out rc
    out=$(python3 "$XBD_PREFIX/tools/browserprobe.py" "$f" --save --json 2>/dev/null); rc=$?
    case "$rc" in
      0) ok=$((ok+1)); printf '\033[32m✓ 可用\033[0m %s\n' "$(printf '%s' "$out" | python3 -c 'import sys,json;print(json.load(sys.stdin).get("exit_ip",""))' 2>/dev/null)";;
      2) skip=$((skip+1)); printf '\033[33m— 无法判定\033[0m %s\n' "$(printf '%s' "$out" | python3 -c 'import sys,json;print(json.load(sys.stdin).get("reason",""))' 2>/dev/null)";;
      *) bad=$((bad+1)); printf '\033[31m✗ 不可用\033[0m %s\n' "$(printf '%s' "$out" | python3 -c 'import sys,json;print(json.load(sys.stdin).get("reason",""))' 2>/dev/null)";;
    esac
  done
  info ""
  info "结果已写回节点文件，xbd node list 与面板会按实测显示"
  [ "$bad" -gt 0 ] && warn "$bad 个节点浏览器路径不可用 —— 用原生 TLS 即可，入口不变"
  return 0
}

# 让运行中的 Xray 与其环境变量声明保持一致（带不带 XRAY_BROWSER_DIALER）。
# 返回 0 = 已一致或已重启成功；1 = 重启失败。
_xbd_sync_xray_with_node() {   # $1=force 时无条件重启（换节点用）
  local want="no"
  _xbd_node_needs_dialer && want="yes"
  local pid have="no"
  pid=$(systemctl show -p MainPID --value "$XBD_U_XRAY" 2>/dev/null || echo 0)
  if [ "${pid:-0}" -gt 0 ] && tr '\0' '\n' < "/proc/$pid/environ" 2>/dev/null | grep '^XRAY_BROWSER_DIALER=' >/dev/null; then
    have="yes"
  fi
  [ "${1:-}" != "force" ] && [ "$want" = "$have" ] && return 0
  info "正在重启 Xray 让节点/浏览器开关生效…"
  systemctl restart "$XBD_U_XRAY" 2>/dev/null || true
  sleep 4
  unit_active "$XBD_U_XRAY" || return 1
  # Xray 重启会让页面上的 CSRF token 作废，所以 Chromium 必须跟着重启
  if [ "$want" = "yes" ] && unit_active "$XBD_U_CHROMIUM"; then
    systemctl restart "$XBD_U_CHROMIUM" 2>/dev/null || true
  fi
  ok "Xray 已按当前节点设置重启（浏览器 $( [ "$want" = yes ] && echo 启用 || echo 关闭 )）"
  return 0
}

cmd_node_remove() {
  local t="${1:-}"
  [ -n "$t" ] || die "用法: xbd node remove <编号|文件名>"
  local path
  if [[ "$t" =~ ^[0-9]+$ ]]; then
    path=$(xbd_node_path "$t")
  else
    path=$(xbd_node_path "$t")
  fi
  [ -e "${path:-}" ] || die "找不到节点: $t"
  local base; base=$(basename "$path")
  if [ -L "$XBD_NODES/current" ] && [ "$(basename "$(readlink -f "$XBD_NODES/current")")" = "$base" ]; then
    die "不能删除当前正在使用的节点，先切换到别的节点"
  fi
  rm -f "$path"
  ok "已删除 $base"
}

# 节点延时：真实发一次请求测完整往返，比 TCP ping 准
cmd_node_latency() {
  local t="${1:-}"
  local files=()
  if [ -z "$t" ]; then
    local f
    for f in "$XBD_NODES"/node-*.json; do [ -e "$f" ] && files+=("$f"); done
    [ ${#files[@]} -gt 0 ] || die "还没有节点"
  elif [[ "$t" =~ ^[0-9]+$ ]]; then
    local p; p=$(xbd_node_path "$t")
    [ -n "$p" ] || die "没有编号 $t 的节点"
    files=("$p")
  else
    local p=$(xbd_node_path "$t")
    [ -e "${p:-}" ] || die "找不到节点: $t"
    files=("$p")
  fi

  step "延时测试（真实请求，每个节点约 3-10 秒）"
  local current; current=$(readlink -f "$XBD_NODES/current" 2>/dev/null || true)
  # 注意：不要把 "$@" 再传给 python —— 之前那样会把 --json 之类参数重复传入，
  # curl 收到未知参数会失败，却被误判成节点不通。
  XBD_PREFIX="$XBD_PREFIX" XBD_DIST="$(xbd_dist_dir)" \
    python3 "$XBD_LIBDIR/latency.py" "${files[@]}"
  info ""
  info "口径：一次 https 请求的完整往返时间（含建连/TLS/传输协议），已预热"
}

cmd_node_check() {
  local t="${1:-}"
  local path="$XBD_NODES/current"
  if [ -n "$t" ]; then
    if [[ "$t" =~ ^[0-9]+$ ]]; then
      path=$(xbd_node_path "$t")
    else
      path=$(xbd_node_path "$t")
    fi
  fi
  [ -e "${path:-}" ] || die "找不到节点"
  python3 "$XBD_LIBDIR/compat.py" render "$path"
}

# ---------------------------------------------------------------------------
# 生命周期：Xray 常驻 与 Browser Dialer 完全解耦
# ---------------------------------------------------------------------------
_xbd_dns_mode() {  # 读 config/dns.env，认不出的值一律当 off
  local m
  m=$(cfg_get "$XBD_CONF/dns.env" "DNS_MODE" "off")
  case "$m" in off|standard|strict) printf '%s' "$m" ;; *) printf 'off' ;; esac
}

cmd_apply() {
  need_root
  require_current_node >/dev/null
  step "生成运行配置"
  xbd_load_ports
  XBD_DNS_MODE=$(_xbd_dns_mode); export XBD_DNS_MODE
  XBD_ADDR_FAMILY=$(_xbd_family); export XBD_ADDR_FAMILY
  # 走多出站还是单节点，判据只有一个来源：compat.py want-bd，和 run-xray.sh 用的是
  # 同一个判定。两边各判各的就会出现"配置按多出站生成、启动时却按单节点起"，
  # 而症状是 balancer 选中的节点根本不在配置里。
  local want_bd
  want_bd=$(python3 "$XBD_LIBDIR/compat.py" want-bd "$XBD_NODES/current" 2>/dev/null || echo no)
  [ "$want_bd" = "yes" ] || want_bd=no

  local -a gen_args=(
    --output "$XBD_RUNTIME/xray-client.json" --mode normal
    --listen "$XBD_LISTEN_ADDR" --port-normal "$XBD_PORT_NORMAL"
    --http-port "$XBD_PORT_HTTP" --lan-http-port "$XBD_PORT_LAN_HTTP"
    --api-port "${XBD_API_PORT:-18085}" --logs "$XBD_LOGS"
    --dns "${XBD_DNS_MODE:-off}"
    --family "${XBD_ADDR_FAMILY:-auto}"
    --validate-with "$XBD_XRAY"
  )
  # validate-with 让 genconfig 自己把构建不出来的节点剔掉。多出站把所有节点塞进
  # 同一份配置，一条坏节点就足以让整份配置通不过校验 —— 服务直接起不来。
  #
  # 多出站默认关闭，开启了才让所有节点常驻一份配置（切换不断线）。
  # 与 run-xray.sh 读同一个 multi.env，两边判断必须一致 —— 不一致就会出现
  # "面板说是多出站、实际是单节点"这种最难查的状态。
  local multi_mode
  multi_mode=$(_xbd_multi_mode)
  if [ "$want_bd" = "yes" ]; then
    gen_args+=(--node "$XBD_NODES/current")     # Browser Dialer 只能单节点
  elif [ "$multi_mode" = "on" ]; then
    gen_args+=(--all-nodes --nodes-dir "$XBD_NODES" --node "$XBD_NODES/current")
  else
    gen_args+=(--node "$XBD_NODES/current")
  fi
  [ -x "$XBD_XRAY" ] && gen_args+=(--validate-with "$XBD_XRAY")

  _gen_out=$(python3 "$XBD_LIBDIR/genconfig.py" "${gen_args[@]}" 2>&1)
  if printf '%s' "$_gen_out" | grep '"ok": true' >/dev/null; then
    # ★ `|| true` 不能省。genconfig 成功、没有警告行时 grep **无匹配返回 1**,
    #   pipefail 让整条管道非零, set -e 会在这里杀掉脚本 —— 而且是"健康路径上
    #   才炸"：配置已经写好了, 但后面的重启永远不执行, 表现成"改了配置不生效
    #   还不报错"。这是同类 set -e 事故的第三例。
    printf '%s\n' "$_gen_out" | grep 'genconfig:' | while read -r l; do warn "  $l"; done || true
    if [ "$want_bd" = "yes" ]; then
      ok "xray-client.json（单节点 · 浏览器拨号）"
    else
      local n
      n=$(python3 -c 'import json,sys
try: print(len(json.load(open(sys.argv[1]))["tags"]))
except Exception: print(0)' "$XBD_RUNTIME/xray-gen.json" 2>/dev/null || echo 0)
      ok "xray-client.json（$n 个节点常驻出站，切换不重启）"
    fi
  # 降级只在"本来想走多出站"时才有意义。
  #
  # 多出站默认关闭后, 这个条件还挂在 want_bd 上就成了 bug: 正常单节点生成
  # 走的是上面那个 if, 没问题; 但一旦生成失败, 会去试"降级成单节点" ——
  # 而它本来就是单节点, 于是白跑一趟, 失败时 die 还会把调用方一起掐断。
  # 症状是 `xbd multi off` 改完配置却不重启、也不报任何错。
  elif [ "$want_bd" != "yes" ] && [ "$multi_mode" = "on" ]; then
    # 回退：多出站生成不出来，就退成单节点。
    #
    # 为什么必须有这条：多出站把所有节点塞进一份配置，任何一处不通都让整份配置
    # 失败。剔除坏节点能挡住"节点本身写错"，但挡不住内核版本变化、字段改名之类
    # 的整体性问题 —— 那种情况下生成会整个失败。如果失败就是 die，用户手里就
    # 一个起不来的客户端，连临时用一下都不行。
    #
    # 单节点配置只含当前节点，能生成成功的概率高得多。先让它跑起来，比什么都强。
    warn "多出站配置生成失败，自动降级为单节点模式"
    # 循环体末命令不能是 `[ ... ] && cmd`：最后一行若是空行, [ -n ] 返回 1,
    # 那正是循环体的最后一条命令, 循环退出码就是 1 —— 同样会被 set -e 杀。
    printf '%s\n' "$_gen_out" | tail -3 | while read -r l; do
      if [ -n "$l" ]; then dim "  $l"; fi
    done
    _fb=(--node "$XBD_NODES/current" --api-port "${XBD_API_PORT:-18085}"
         --logs "$XBD_LOGS" --dns "${XBD_DNS_MODE:-off}" --port-normal "${XBD_PORT_NORMAL:-1080}"
         --family "${XBD_ADDR_FAMILY:-auto}"
         --listen-addr "${XBD_LISTEN_ADDR:-127.0.0.1}" --loglevel "${XBD_LOGLEVEL:-warning}")
    if python3 "$XBD_LIBDIR/genconfig.py" "${_fb[@]}" 2>&1 | grep '"ok": true' >/dev/null; then
      ok "xray-client.json（单节点 · 已降级，切换节点需重启）"
      warn "降级期间切换节点会断一次。想恢复多出站，先查上面的报错。"
    else
      die "xray-client.json 生成失败（单节点模式也一样），这是致命的"
    fi
  else
    printf '%s\n' "$_gen_out" | tail -5 >&2
    die "xray-client.json 生成失败，这是致命的"
  fi
}

# 让一个单元"跑起来、而且跑的是当前这份配置/代码"。
#
# ★ `systemctl enable --now` 对**已经 active** 的单元是**空操作** —— 不报错，
#   也不重启。所以更新之后走一遍 cmd_start，服务其实还在跑旧代码：
#   面板进程把 PAGE 在启动时读进内存，不重启就永远服务旧界面。
#   CC 上实测：更新到 2.2.0 之后浏览器里看到的还是旧界面，而磁盘上的
#   panel.py 已经是新的 —— 面板服务的启动时间停在更新之前。
#   用户看到的是"装完了但什么都没变"，这是最难自己排查的一类。
_xbd_up_unit() {
  local u="$1"
  if unit_active "$u"; then
    # 起着，但要换一份 → restart（不是 start，start 对 active 单元也是空操作）
    systemctl restart "$u" 2>/dev/null || systemctl start "$u"
  else
    systemctl enable --now "$u" >/dev/null 2>&1 || systemctl start "$u"
  fi
}

cmd_start() {
  need_root
  require_current_node >/dev/null
  xbd_load_ports
  cmd_apply

  step "启动 Xray（唯一实例：SOCKS + HTTP）"
  _xbd_up_unit "$XBD_U_XRAY"
  sleep 4
  unit_active "$XBD_U_XRAY" && ok "$XBD_U_XRAY: RUNNING" || { bad "$XBD_U_XRAY 启动失败"; journalctl -u "$XBD_U_XRAY" -n 15 --no-pager; return 1; }
  # Xray 重启换了 CSRF token，浏览器必须跟着重启（旧 WS 会挂着但已失效）
  unit_active "$XBD_U_CHROMIUM" && systemctl restart "$XBD_U_CHROMIUM" 2>/dev/null || true

  # Chromium 只在**当前节点需要浏览器**时才拉起来。
  # 旧的"常备"模型已经废弃：它无条件启动 Chromium，节点换到 hysteria 这类不用
  # 浏览器的协议后，这个进程会一直占着约 600MB（这台机器总共 1.8GB）。
  # 判据与 run-xray.sh / 换节点 / 健康检查完全一致：都用 compat.py want-bd。
  if _xbd_node_needs_dialer; then
    step "启动 Browser Dialer 运行时（Chromium）"
    systemctl enable --now "$XBD_U_CHROMIUM" >/dev/null 2>&1 || systemctl start "$XBD_U_CHROMIUM"
    systemctl enable --now "$XBD_U_TIMER" >/dev/null 2>&1 || true
    local i
    for i in 1 2 3 4 5 6 7 8 9 10; do
      unit_active "$XBD_U_CHROMIUM" && [ "$(conn_count '127.0.0.1:18081')" -gt 0 ] && break
      sleep 1
    done
    if unit_active "$XBD_U_CHROMIUM"; then
      ok "$XBD_U_CHROMIUM: RUNNING（$XBD_U_TIMER 负责自愈）"
    else
      warn "$XBD_U_CHROMIUM 未启动 —— 依赖浏览器拨号的节点会失败（xbd dialer on 可重试）"
    fi
  else
    step "Browser Dialer 运行时（Chromium）"
    if unit_active "$XBD_U_CHROMIUM"; then
      warn "当前节点不用浏览器，停掉 Chromium 释放内存"
      xbd_dialer_off || true
    else
      ok "当前节点走 Xray 自带 TLS，Chromium 无需运行"
    fi
  fi

  step "启动面板"
  _xbd_up_unit "$XBD_U_PANEL"
  sleep 2
  unit_active "$XBD_U_PANEL" && ok "$XBD_U_PANEL: RUNNING ($(xbd_panel_url))" || warn "面板未启动（不影响代理）"

  info ""
  ok "已就绪。局域网设备可连接 ${XBD_LISTEN_ADDR}:${XBD_PORT_NORMAL}(SOCKS5) / ${XBD_LISTEN_ADDR}:${XBD_PORT_LAN_HTTP}(HTTP)"
  info "两个入口都是全部节点通用；需要浏览器拨号的节点会自动使用 Chromium"
}

cmd_stop() {
  need_root
  # 分层：默认只停常驻 Xray；--all 才连面板块停
  local all=0
  [ "${1:-}" = "--all" ] && all=1

  step "停止 Xray"
  systemctl stop "$XBD_U_XRAY" 2>/dev/null || true
  ok "$XBD_U_XRAY: STOPPED"
  # Chromium 单独跑着没有意义（它的页面连不到 Xray），顺手停掉释放内存
  if unit_active "$XBD_U_CHROMIUM"; then
    systemctl stop "$XBD_U_CHROMIUM" 2>/dev/null || true
    ok "$XBD_U_CHROMIUM: STOPPED（Xray 已停，浏览器无对象可连）"
  fi

  if [ "$all" -eq 1 ]; then
    xbd_dialer_off || true
    systemctl stop "$XBD_U_TIMER" 2>/dev/null || true
    systemctl stop "$XBD_U_PANEL" 2>/dev/null || true
    ok "已全部停止"
  else
    info "面板保持运行，可从网页再启动: $(xbd_panel_url)"
  fi
  info "单元仍为 enabled，重启机器会自动启动"
}

cmd_restart() {
  need_root
  systemctl restart "$XBD_U_XRAY"
  sleep 3
  ok "$XBD_U_XRAY 已重启"
  # Xray 重启会换 CSRF token，官方页面只重试 socket、不重载自己，
  # 所以浏览器必须跟着重启，否则 WS 永远连不上。
  if unit_active "$XBD_U_CHROMIUM"; then
    systemctl restart "$XBD_U_CHROMIUM" 2>/dev/null || true
  fi
  cmd_status
}

# Chromium 进程数。必须返回**单个整数**：
#   pgrep -c 在本机会按每个匹配进程各输出一行，`| head -1` 拿到的可能是多行串，
#   于是 [ "$n" -eq 0 ] 报 "integer expression expected"（实测踩过）。
# 必须用 -x（精确匹配进程名）并且**不要用 -f**：
#   -f 会匹配整条命令行，把调用者自己（shell/pgrep）也算进去，数目虚高（实测 13 vs 真值 9）。
# pgrep -c 输出的就是计数本身，直接用它，别去数行数。
chromium_procs() {
  local n
  n=$(pgrep -c -x chromium 2>/dev/null)
  case "$n" in ''|*[!0-9]*) echo 0 ;; *) echo "$n" ;; esac
}

# ---------------------------------------------------------------------------
# Browser Dialer 的运行时依赖（Chromium）启停
#
# 唯一 Xray 实例**始终**带 XRAY_BROWSER_DIALER，所以这里控制的不是"模式"，
# 而是"浏览器在不在线"：
#   * Chromium 在线 -> 所有节点都可用（BD 节点走浏览器 TLS，其余走 Xray TLS）
#   * Chromium 停掉 -> BD 节点（xhttp/websocket 且非 REALITY）会拨号失败，
#                      其他节点完全不受影响
# ---------------------------------------------------------------------------
cmd_dialer() {
  local op="${1:-status}"
  case "$op" in
    on|start|enable)  xbd_dialer_on ;;
    off|stop|disable) xbd_dialer_off ;;
    toggle)           if unit_active "$XBD_U_CHROMIUM"; then xbd_dialer_off; else xbd_dialer_on; fi ;;
    status|"")        xbd_dialer_status ;;
    -h|--help)        info "用法: xbd dialer <on|off|toggle|status>" ;;
    *) die "未知操作: $op" ;;
  esac
}

# 当前节点**实际**要不要用浏览器完成 TLS。
#
# 判定顺序（与面板、health timer 共用同一套语义，避免两处判断打架）：
#   1. 协议必须支持（xhttp/websocket 且非 REALITY）—— 不支持则永远不用浏览器
#   2. 节点自己的 use_browser 开关：
#        None  -> 默认，协议支持就用
#        True  -> 用
#        False -> 不用，即使协议支持（用户可为单个节点关掉）
#
# 这是**每个节点各自的属性**，不是全局模式：以前做成全局开关时，一关就让所有
# 依赖浏览器的节点一起失效（实测踩过），而只是某个节点想省内存时不该牵连别人。
_xbd_node_needs_dialer() {
  # 判定只有一个来源：compat.py want-bd（与 run-xray.sh、health-check.sh 共用）。
  # 以前这里自己写了一套 python，三处语义容易走偏 —— 而走偏的后果是节点永久挂住。
  local node; node=$(readlink -f "$XBD_NODES/current" 2>/dev/null || true)
  [ -n "$node" ] && [ -e "$node" ] || return 1
  [ "$(python3 "$XBD_LIBDIR/compat.py" want-bd "$node" 2>/dev/null)" = "yes" ]
}

# 该节点**协议层面**是否可能走浏览器转发（不管实测通不通）。
# 与 _xbd_node_needs_dialer 的区别：这个不考虑 use_browser 开关，只看"能不能"。
# 用途：决定 Chromium 能不能停 —— 只要还可能用到，就不能停（停了会无限挂住）。
_xbd_node_may_use_browser() {
  # 协议层面是否**可能**走浏览器（不管实测通不通、不管用户开关）。
  # 用途：决定 Chromium 能不能停 —— 只要还可能用到就不能停（停了会无限挂住）。
  local node; node=$(readlink -f "$XBD_NODES/current" 2>/dev/null || true)
  [ -n "$node" ] && [ -e "$node" ] || return 1
  python3 "$XBD_LIBDIR/compat.py" json "$node" 2>/dev/null \
    | python3 -c 'import sys,json;print(json.load(sys.stdin).get("protocol_may_dialer"))' 2>/dev/null \
    | grep -x True >/dev/null
}

# 该节点能不能用浏览器（用于面板置灰）。与"要不要用"分开，因为要区分
# "不支持所以关着"和"支持但用户自己关的"。
_xbd_node_can_dialer() {
  local node; node=$(readlink -f "$XBD_NODES/current" 2>/dev/null || true)
  [ -n "$node" ] && [ -e "$node" ] || return 1
  python3 "$XBD_LIBDIR/compat.py" json "$node" 2>/dev/null \
    | python3 -c 'import sys,json;print(json.load(sys.stdin).get("can_use_dialer"))' 2>/dev/null \
    | grep -x True >/dev/null
}

xbd_dialer_status() {
  printf '  Xray（唯一实例）: %s\n' "$(unit_active "$XBD_U_XRAY" && echo "Running" || echo "Stopped")"
  printf '  Chromium:         %s\n' "$(unit_active "$XBD_U_CHROMIUM" && echo "Running" || echo "Stopped")"
  local la; la=$(cfg_get "$XBD_CONF/ports.env" LISTEN_ADDR 127.0.0.1)
  printf '  SOCKS5 入口:      %s:%s（全部节点）\n' "$la" "$(cfg_get "$XBD_CONF/ports.env" PORT_NORMAL 1080)"
  printf '  HTTP  入口(LAN):  %s:%s（全部节点）\n' "$la" "$(cfg_get "$XBD_CONF/ports.env" PORT_LAN_HTTP 10809)"
  printf '  HTTP  入口(本机): 127.0.0.1:%s\n' "$(cfg_get "$XBD_CONF/ports.env" PORT_HTTP 10808)"
  printf '  浏览器连接数:     %s\n' "$(conn_count '127.0.0.1:18081')"
  if _xbd_node_needs_dialer; then
    if unit_active "$XBD_U_CHROMIUM"; then
      printf '  当前节点:         依赖浏览器拨号 —— Chromium 在线，可用 ✓\n'
    else
      printf '  当前节点:         ⚠ 依赖浏览器拨号，但 Chromium 已停 —— 该节点会拨号失败\n'
      printf '  修复:             xbd dialer on\n'
    fi
  else
    printf '  当前节点:         不依赖浏览器拨号（走 Xray 自带 TLS）\n'
  fi
}

xbd_dialer_on() {
  need_root
  step "确保 Browser Dialer 运行时（Chromium）在线"
  xbd_load_ports          # 末尾要打印两个入口，必须先把端口读进来
  require_current_node >/dev/null || true

  if ! unit_active "$XBD_U_XRAY"; then
    warn "Xray 未运行，先启动它"
    cmd_start >/dev/null 2>&1 || true
  fi

  systemctl start "$XBD_U_CHROMIUM" 2>/dev/null || true
  systemctl enable --now "$XBD_U_TIMER" >/dev/null 2>&1 || true
  local i
  for i in 1 2 3 4 5 6 7 8 9 10; do
    unit_active "$XBD_U_CHROMIUM" && [ "$(conn_count '127.0.0.1:18081')" -gt 0 ] && break
    sleep 1
  done

  if ! unit_active "$XBD_U_CHROMIUM"; then
    bad "$XBD_U_CHROMIUM 启动失败"
    journalctl -u "$XBD_U_CHROMIUM" -n 12 --no-pager
    return 1
  fi

  # 真实校验两端是否接上。只看"端口在听"不够 ——
  # 端口改过而 Chromium 没跟上时，两边各自"正常"但一条 WS 都没有。
  local chk vok vws vmismatch
  chk=$(python3 "$XBD_LIBDIR/ports.py" verify-dialer --json 2>/dev/null || echo '{}')
  vok=$(printf '%s' "$chk" | python3 -c 'import sys,json;print(json.load(sys.stdin).get("ok"))' 2>/dev/null || echo False)
  vws=$(printf '%s' "$chk" | python3 -c 'import sys,json;print(json.load(sys.stdin).get("ws_connections",0))' 2>/dev/null || echo 0)
  vmismatch=$(printf '%s' "$chk" | python3 -c 'import sys,json;print(json.load(sys.stdin).get("mismatch"))' 2>/dev/null || echo False)

  if [ "$vmismatch" = "True" ]; then
    bad "端口不一致：Chromium 连的不是 Xray 监听的端口"
    info "  修正: xbd port channel <端口>  然后 systemctl restart $XBD_U_CHROMIUM"
    return 1
  fi
  if [ "$vok" = "True" ]; then
    ok "$XBD_U_CHROMIUM: RUNNING（浏览器已接上，$vws 条 WS）"
  else
    warn "$XBD_U_CHROMIUM RUNNING，但浏览器还没接上 —— health timer 会在 30 秒内自愈"
    info "  若一直不恢复: xbd ports verify"
  fi
  info "两个入口都可用: ${XBD_LISTEN_ADDR}:${XBD_PORT_NORMAL}(SOCKS5) / ${XBD_LISTEN_ADDR}:${XBD_PORT_LAN_HTTP}(HTTP)"
}

xbd_dialer_off() {
  need_root
  step "停掉 Browser Dialer 运行时（Chromium）"
  systemctl stop "$XBD_U_CHROMIUM" 2>/dev/null || true
  systemctl stop "$XBD_U_TIMER" 2>/dev/null || true

  # 等 Chromium 子进程真正退出
  local i procs
  for i in 1 2 3 4 5 6 7 8; do
    procs=$(chromium_procs)
    [ "${procs:-0}" -eq 0 ] && break
    sleep 1
  done
  procs=$(chromium_procs)

  ok "$XBD_U_CHROMIUM: STOPPED（残留进程 $procs）"
  if unit_active "$XBD_U_XRAY"; then
    ok "$XBD_U_XRAY: 继续运行 ✓（SOCKS/HTTP 两个入口都在，普通节点不受影响）"
  else
    warn "$XBD_U_XRAY 未在运行"
  fi
  if _xbd_node_needs_dialer; then
    warn "当前节点依赖浏览器拨号，Chromium 停掉后它会拨号失败 —— xbd dialer on 恢复"
  fi
}

# ---------------------------------------------------------------------------
# 端口
# ---------------------------------------------------------------------------
cmd_port() {
  local which="${1:-}" value="${2:-}"
  xbd_load_ports
  if [ -z "$which" ]; then
    printf '  当前端口分配:\n'
    printf '    %-34s %s\n' "LAN SOCKS5（全部节点）"   "$XBD_PORT_NORMAL"
    printf '    %-34s %s\n' "本机 HTTP 代理（docker 等）" "$XBD_PORT_HTTP"
    printf '    %-34s %s\n' "局域网 HTTP 代理（WiFi）" "$XBD_PORT_LAN_HTTP"
    printf '    %-34s %s\n' "Xray↔Chromium 内部通道"  "$XBD_DIALER_ADDR"
    printf '    %-34s %s\n' "面板"                    "$XBD_PANEL_PORT"
    printf '    %-34s %s\n' "Xray 统计 API"           "${XBD_API_PORT:-18085}"
    printf '    %-34s %s\n' "绑定地址"                "$XBD_LISTEN_ADDR"
    info ""
    info "修改: xbd port <类型> <值>"
    info "  类型: normal | http | lan-http | channel | panel | api | addr"
    info "自动分配: xbd ports fix    检查冲突: xbd ports check"
    return 0
  fi

  need_root
  case "$which" in
    normal|n)     [ -n "$value" ] || die "缺端口值"; _xbd_set_port PORT_NORMAL "$value" normal ;;
    http|h)       [ -n "$value" ] || die "缺端口值"; _xbd_set_port PORT_HTTP "$value" xray ;;
    lan-http|lh)  [ -n "$value" ] || die "缺端口值"; _xbd_set_port PORT_LAN_HTTP "$value" xray ;;
    api)          [ -n "$value" ] || die "缺端口值"; _xbd_set_port API_PORT "$value" xray ;;
    channel|ch)
      [ -n "$value" ] || die "缺端口值"
      _xbd_check_port_num "$value"
      local holder; holder=$(port_holder "$value")
      [ -z "$holder" ] || [ "$(printf '%s' "$holder" | grep -c xray)" -gt 0 ] || die "端口 $value 已被占用（${holder:0:60}）"
      # 内部通道改端口必须**两边一起改**，否则 Chromium 还连旧端口（实测过这个坑）
      cfg_set "$XBD_CONF/ports.env" DIALER_ADDR "127.0.0.1:$value"
      cfg_set "$XBD_CONF/chromium.env" BROWSER_DIALER_ADDR "127.0.0.1:$value"
      ok "内部通道 → 127.0.0.1:$value（ports.env / chromium.env 已同步）"
      info "生效需要重启两边: systemctl restart $XBD_U_XRAY $XBD_U_CHROMIUM"
      ;;
    panel|p)
      [ -n "$value" ] || die "缺端口值"
      _xbd_check_port_num "$value"
      cfg_set "$XBD_CONF/panel.env" PANEL_PORT "$value"
      ok "面板端口 → $value"
      systemctl restart "$XBD_U_PANEL" 2>/dev/null || true
      info "面板新地址: http://$(cfg_get "$XBD_CONF/panel.env" PANEL_HOST 127.0.0.1):$value/"
      return 0
      ;;
    addr|listen)  [ -n "$value" ] || die "缺地址值"; cfg_set "$XBD_CONF/ports.env" LISTEN_ADDR "$value"; ok "绑定地址 → $value" ;;
    *) die "未知端口类型: $which（可选 normal/http/lan-http/channel/panel/api/addr）" ;;
  esac
  info "执行 xbd restart 生效"
}

# 端口子命令：检查与自动修复
cmd_ports() {
  local op="${1:-check}"
  case "$op" in
    check)  python3 "$XBD_LIBDIR/ports.py" check ;;
    fix|auto)
      need_root
      step "检查并修复端口冲突"
      local out; out=$(python3 "$XBD_LIBDIR/ports.py" check --json)
      local n; n=$(printf '%s' "$out" | python3 -c '
import sys, json
print(len(json.load(sys.stdin).get("problems", [])))' 2>/dev/null || echo 0)
      if [ "${n:-0}" -eq 0 ]; then
        ok "没有端口冲突（本项目服务占用自己的端口属正常）"
        return 0
      fi
      warn "发现 $n 处冲突，正在重新分配"
      printf '%s' "$out" | python3 -c '
import sys, json
for p in json.load(sys.stdin).get("problems", []):
    print(f"  {p["label"]}: {p["port"]} 被占用（{p["holder"][:50]}）→ 改用 {p["suggest"]}")
'
      # 逐项应用建议值（只改被占用的那些）
      local which port
      while IFS=$'\t' read -r which port; do
        [ -z "$which" ] && continue
        case "$which" in
          PORT_NORMAL)   _xbd_set_port PORT_NORMAL "$port" normal ;;
          PORT_HTTP)     _xbd_set_port PORT_HTTP "$port" xray ;;
          PORT_LAN_HTTP) _xbd_set_port PORT_LAN_HTTP "$port" xray ;;
          API_PORT)      _xbd_set_port API_PORT "$port" xray ;;
          PANEL_PORT)    cfg_set "$XBD_CONF/panel.env" PANEL_PORT "$port"; ok "面板端口 → $port" ;;
          DIALER_ADDR)   cfg_set "$XBD_CONF/ports.env" DIALER_ADDR "127.0.0.1:$port"
                         cfg_set "$XBD_CONF/chromium.env" BROWSER_DIALER_ADDR "127.0.0.1:$port"
                         ok "内部通道 → $port" ;;
        esac
      done < <(printf '%s' "$out" | python3 -c '
import sys, json
for p in json.load(sys.stdin).get("problems", []):
    print(p["key"] + "\t" + str(p["suggest"]))
')
      cmd_apply >/dev/null 2>&1 || true
      systemctl restart "$XBD_U_XRAY" 2>/dev/null || true
      systemctl restart "$XBD_U_PANEL" 2>/dev/null || true
      ok "已修复。执行 xbd status 查看"
      ;;
    verify)
      python3 "$XBD_LIBDIR/ports.py" verify-dialer ;;
    -h|--help|"") info "用法: xbd ports <check|fix|verify>" ;;
    *) die "未知操作: $op" ;;
  esac
}

_xbd_check_port_num() {
  [[ "$1" =~ ^[0-9]+$ ]] && [ "$1" -ge 1 ] && [ "$1" -le 65535 ] || die "端口必须是 1-65535 的数字"
}

_xbd_set_port() {
  local key="$1" new="$2" reload="${3:-}"
  _xbd_check_port_num "$new"
  # API 端口存独立文件；其余在 ports.env
  local file="$XBD_CONF/ports.env"
  [ "$key" = "API_PORT" ] && file="$XBD_CONF/api.env"
  local cur holder
  cur=$(cfg_get "$file" "$key" "")
  [ "$new" = "$cur" ] && { ok "端口已经是 $new"; return 0; }
  holder=$(port_holder "$new")
  # 自己占着的端口允许改（例如重启后重新分配）
  if [ -n "$holder" ] && ! printf '%s' "$holder" | grep xray >/dev/null; then
    die "端口 $new 已被占用（${holder:0:70}）"
  fi
  cfg_set "$file" "$key" "$new"
  ok "$key: ${cur:-未设置} → $new"
  case "$reload" in
    xray)   systemctl restart "$XBD_U_XRAY" 2>/dev/null || true ;;
    panel)  systemctl restart "$XBD_U_PANEL" 2>/dev/null || true ;;
    normal|dialer|"") : ;;
  esac
}

# ---------------------------------------------------------------------------
# 状态 / 诊断
# ---------------------------------------------------------------------------
cmd_status() {
  if [ ! -x "$XBD_XRAY" ]; then
    warn "尚未安装（找不到 $XBD_XRAY）"
    info "安装: xbd install"
    return 2
  fi
  local quick=""
  [ "${1:-}" = "--quick" ] && quick="--quick"
  XBD_PREFIX="$XBD_PREFIX" python3 "$XBD_LIBDIR/state.py" $quick
}

# ---------------------------------------------------------------- 浏览器运行时
#
# Browser Dialer 需要 Chromium。这里回答三个问题：**装没装 / 装了哪个版本 /
# 一个命令怎么装**。
#
# 为什么不自动装: 浏览器是几百 MB 的包, 而且在 Debian/Ubuntu 上 `chromium`
# 可能是 snap 壳（装上了也起不来）。默认只检测 + 给命令, 用户明确说了才装 ——
# "装个客户端顺手给我拖半个浏览器下来"不是所有人都想要的。
xbd_browser_installed() {
  local b; b=$(detect_browser 2>/dev/null) || return 1
  printf '%s' "$b"
}

xbd_browser_status() {
  local b ver
  if b=$(xbd_browser_installed); then
    ver=$(browser_version 2>/dev/null)
    ok "浏览器: $b"
    [ -n "$ver" ] && dim "         $ver"
  else
    warn "系统里没有 Chromium / Chrome —— 依赖浏览器拨号的节点会不可用"
    info "  其余节点不受影响（是否走浏览器由节点自身决定）"
    info "  安装: xbd browser install"
  fi
  local st; st=$(unit_state "$XBD_U_CHROMIUM")
  case "$st" in
    active)   ok "Chromium 运行时: 运行中" ;;
    inactive) info "Chromium 运行时: 未运行（按需启动即可，省内存）" ;;
    *)        warn "Chromium 运行时: $st" ;;
  esac
  # 当前节点到底需不需要它 —— 用户最容易被"Chromium 没跑"误导
  local curf need
  curf=$(current_node_file 2>/dev/null || true)
  if [ -n "$curf" ]; then
    need=$(python3 "$XBD_LIBDIR/compat.py" json "$curf" 2>/dev/null \
           | python3 -c 'import json,sys;print("yes" if json.load(sys.stdin).get("can_use_dialer") else "no")' 2>/dev/null || echo '?')
    case "$need" in
      yes) info "当前节点: 需要浏览器拨号（先 xbd dialer on）" ;;
      no)  info "当前节点: 不需要浏览器（走 Xray 自带 TLS）" ;;
      *)   info "当前节点: 判定不出来（xbd node check）" ;;
    esac
  fi
}

xbd_browser_install() {
  need_root
  local yes=0; [ "${1:-}" = "--yes" ] && yes=1
  if xbd_browser_installed >/dev/null; then
    ok "已经装了: $(xbd_browser_installed)"
    return 0
  fi
  local pm="" pkg=""
  if command -v apt-get >/dev/null 2>&1; then
    pm="apt-get"; pkg="chromium"
    # Debian 系的 chromium 在新版里是 snap 壳, 装上也可能起不来 —— 明确说清
    if grep -qi debian /etc/os-release 2>/dev/null; then
      warn "Debian 的 chromium 包可能是 snap 壳（装完也起不来）"
      info "  更稳的做法: 用 xtradeb 源（Ubuntu）或装 google-chrome-stable"
    fi
  elif command -v dnf >/dev/null 2>&1; then
    pm="dnf"; pkg="chromium"
  elif command -v apk >/dev/null 2>&1; then
    pm="apk"; pkg="chromium"
  else
    bad "认不出包管理器，请手动安装 Chromium / Google Chrome"
    return 1
  fi
  info "将执行: $pm install $pkg"
  if [ "$yes" -eq 0 ]; then
    printf '  浏览器是几百 MB 的包，继续吗? [y/N] '
    local a; read -r a || return 0
    case "$a" in y|Y) ;; *) info "已取消"; return 0 ;; esac
  fi
  case "$pm" in
    apt-get) apt-get update -qq && apt-get install -y "$pkg" ;;
    dnf)     dnf install -y "$pkg" ;;
    apk)     apk add --no-cache "$pkg" ;;
  esac || { bad "安装失败 —— 也可以自己装 google-chrome-stable"; return 1; }
  if xbd_browser_installed >/dev/null; then
    ok "装好了: $(xbd_browser_installed)"
    info "下一步: xbd dialer on（或 xbd restart）"
  else
    bad "装完还是找不到浏览器可执行文件 —— 可能是 snap 壳，换 google-chrome-stable 试试"
    return 1
  fi
}

# 网页面板服务（自研面板）：看地址 / 重启 / 停掉
xbd_panel_service() {
  local op="${1:-status}"
  case "$op" in
    status) cmd_panel ;;
    restart)
      need_root
      systemctl restart "$XBD_U_PANEL" && ok "面板已重启" || bad "面板重启失败"
      sleep 1; cmd_panel ;;
    stop)
      need_root
      systemctl stop "$XBD_U_PANEL" && ok "面板已停止（xbd panel restart 可再起来）" \
        || bad "停止失败" ;;
    *) info "用法: xbd panel [status|restart|stop]" ;;
  esac
}

cmd_panel() {
  # 更名说明: `xbd panel` 原来是"只打印地址"。现在多一个管理入口
  # （status/restart/stop），但**不带参数时必须还是打印地址** —— 脚本里
  # 到处都在 `xbd panel | grep` 取地址，改了行为等于把它们全弄坏。
  case "${1:-}" in
    restart|stop) xbd_panel_service "$1"; return $? ;;
    status) ;;
    "") ;;
    *) info "用法: xbd panel [status|restart|stop]"; return 1 ;;
  esac
  xbd_load_ports
  info "面板地址: http://$XBD_PANEL_HOST:$XBD_PANEL_PORT/"
  [ -n "$XBD_PANEL_TOKEN" ] && { info "访问令牌: $XBD_PANEL_TOKEN"; info "完整链接: http://$XBD_PANEL_HOST:$XBD_PANEL_PORT/?token=$XBD_PANEL_TOKEN"; }
  [ "$XBD_PANEL_HOST" = "127.0.0.1" ] && dim "  当前只允许本机访问；要局域网访问把 PANEL_HOST 改成 $(detect_lan_ip)"
  info "配置: $XBD_CONF/panel.env"
}

cmd_diagnose() {
  local quick=0
  [ "${1:-}" = "--quick" ] && quick=1
  xbd_load_ports
  local fails=0 warns=0
  echo "========================================"
  echo "Xray Client + Browser Dialer 诊断"
  echo "========================================"
  _d() { case "$2" in
    PASS) ok "$(printf '%-26s' "$1") $3" ;;
    WARN) warn "$(printf '%-26s' "$1") $3"; warns=$((warns+1)) ;;
    FAIL) bad "$(printf '%-26s' "$1") $3"; fails=$((fails+1)) ;;
  esac; }

  _d "架构/发行版" PASS "$(uname -m) / $(. /etc/os-release 2>/dev/null; printf '%s' "$PRETTY_NAME")"
  [ -x "$XBD_XRAY" ] && _d "Xray 二进制" PASS "$(first_line "$XBD_XRAY" version | cut -c1-40)" || _d "Xray 二进制" FAIL "缺失"
  if BROWSER=$(detect_browser); then _d "浏览器" PASS "$(browser_version | cut -c1-40)"; else _d "浏览器" WARN "未安装（依赖浏览器拨号的节点会不可用，其余节点不受影响）"; fi

  local node; node=$(current_node_file 2>/dev/null || true)
  if [ -n "$node" ]; then
    local caps
    caps=$(python3 "$XBD_LIBDIR/compat.py" json "$node" 2>/dev/null || echo '{}')
    _d "节点 Xray" "$(printf '%s' "$caps" | python3 -c 'import sys,json;print("PASS" if json.load(sys.stdin).get("can_use_xray") else "FAIL")' 2>/dev/null || echo FAIL)" \
       "$(node_field "$node" name)"
    _d "节点 Browser Dialer" "$(printf '%s' "$caps" | python3 -c 'import sys,json;print("PASS" if json.load(sys.stdin).get("can_use_dialer") else "WARN")' 2>/dev/null || echo WARN)" \
       "$(node_field "$node" transport) / $(node_field "$node" security)"
  else
    _d "节点" FAIL "尚未选择"
  fi

  _d "xray-client.service" "$(unit_active "$XBD_U_XRAY" && echo PASS || echo FAIL)" "$(unit_state "$XBD_U_XRAY")（唯一实例）"
  _d "panel.service" "$(unit_active "$XBD_U_PANEL" && echo PASS || echo WARN)" "$(unit_state "$XBD_U_PANEL")"

  # 唯一实例必须同时提供两个入站 —— 任一缺失都是配置/端口问题
  _d "SOCKS5 入口 :$XBD_PORT_NORMAL" "$(port_listening_tcp "$XBD_PORT_NORMAL" && echo PASS || echo FAIL)" "$(port_holder "$XBD_PORT_NORMAL" | cut -c1-40)"
  _d "HTTP 入口 :$XBD_PORT_LAN_HTTP" "$(port_listening_tcp "$XBD_PORT_LAN_HTTP" && echo PASS || echo FAIL)" "$(port_holder "$XBD_PORT_LAN_HTTP" | cut -c1-40)"

  # 同一端口被两个进程绑定 = 当年双实例拆分留下的坑，必须报出来
  local dup
  # 用 awk 收尾而不是 `head -3 | tr`: head 一到 3 行就退出, sort 还在写就被
  # SIGPIPE 杀掉（141）, pipefail + set -e 会直接把 xbd diagnose 掀翻。
  dup=$(ss -H -lntH 2>/dev/null | awk '{print $4}' | sort | uniq -d | awk 'NR<=3{printf "%s ", $0}')
  [ -z "$dup" ] && _d "端口重复绑定" PASS "无" || _d "端口重复绑定" FAIL "$dup"

  # Browser Dialer 的运行时依赖：节点需要它时必须在跑
  local cprocs; cprocs=$(chromium_procs); cprocs=${cprocs:-0}
  local cactive=0; unit_active "$XBD_U_CHROMIUM" && cactive=1
  if _xbd_node_needs_dialer; then
    _d "Chromium: RUNNING" "$([ "$cactive" -eq 1 ] && echo PASS || echo FAIL)" "$cprocs 个进程（当前节点依赖浏览器拨号）"
    _d "浏览器↔Dialer" "$([ "$(conn_count '127.0.0.1:18081')" -gt 0 ] && echo PASS || echo WARN)" "$(conn_count '127.0.0.1:18081') 条 WS"
  else
    _d "Chromium: RUNNING" "$([ "$cactive" -eq 1 ] && echo PASS || echo WARN)" \
      "$cprocs 个进程$([ "$cactive" -eq 0 ] && echo '（当前节点不需要，不影响）')"
  fi

  if [ "$quick" -eq 0 ]; then
    local addr; addr=$(cfg_get "$XBD_CONF/ports.env" LISTEN_ADDR 127.0.0.1)
    local ip
    ip=$(curl -s --max-time 20 --socks5-hostname "$addr:$XBD_PORT_NORMAL" https://api.ipify.org 2>/dev/null || true)
    _d "经代理出网" "$([ -n "$ip" ] && echo PASS || echo FAIL)" "${ip:-失败}（经 :$XBD_PORT_NORMAL）"

    # 两个入站必须走同一个实例 -> 出口必须一致。不一致说明又拆出了第二个实例。
    local iph
    iph=$(curl -s --max-time 20 --proxy "http://$addr:$XBD_PORT_LAN_HTTP" https://api.ipify.org 2>/dev/null || true)
    if [ -n "$ip" ] && [ "$ip" = "$iph" ]; then
      _d "两入口出口一致" PASS "$ip（SOCKS 与 HTTP 同一实例）"
    else
      _d "两入口出口一致" WARN "SOCKS=${ip:-失败} HTTP=${iph:-失败}"
    fi

    local loop=0
    ip -o link show type tun 2>/dev/null | grep . >/dev/null && { _d "本机 TUN" WARN "存在"; loop=1; } || _d "本机 TUN" PASS "无"
    iptables -t nat -S 2>/dev/null | grep -E 'REDIRECT' >/dev/null && { _d "透明重定向" WARN "存在 NAT REDIRECT"; loop=1; } || _d "透明重定向" PASS "无"
    # 旧版本的"接管局域网"模式会留下这张表，即使工具已经不提供那个模式也必须报出来：
    # 残留规则会继续劫持局域网的 80/443 与 DNS，而界面上完全看不出来。
    if nft list table ip xbd_takeover >/dev/null 2>&1 || nft list table ip6 xbd_takeover >/dev/null 2>&1; then
      _d "nft 透明接管残留" WARN "存在 table xbd_takeover（旧版遗留）"
      dim "      清理: nft delete table ip xbd_takeover; nft delete table ip6 xbd_takeover"
      loop=1
    else
      _d "nft 透明接管残留" PASS "无"
    fi
    iptables -t mangle -S 2>/dev/null | grep -E 'TPROXY' >/dev/null && { _d "TPROXY" WARN "存在"; loop=1; } || _d "TPROXY" PASS "无"
    local pe; pe=$(env | grep -cE '^(HTTP_PROXY|HTTPS_PROXY|ALL_PROXY)=' || true)
    [ "${pe:-0}" -eq 0 ] && _d "代理环境变量" PASS "干净" || { _d "代理环境变量" FAIL "存在"; loop=1; }
    [ "$loop" -eq 0 ] && _d "代理环路风险" PASS "无环路迹象" || _d "代理环路风险" WARN "见上"

    _d "LAN 绑定" PASS "$addr（非 0.0.0.0）"
    if [ "$addr" = "0.0.0.0" ] || [ "$addr" = "::" ]; then
      _d "公网暴露" FAIL "监听所有网卡"
    else
      _d "公网暴露" PASS "仅绑 LAN 地址"
    fi
  fi

  _d "既有服务" PASS "xray.service=$(unit_state xray.service 2>/dev/null || echo n/a) mihomo=$(unit_state mihomo.service 2>/dev/null || echo n/a)"
  echo "========================================"
  if [ "$fails" -eq 0 ]; then printf '结果: PASS (%s 项警告)\n' "$warns"; else printf '结果: FAIL (%s 失败, %s 警告)\n' "$fails" "$warns"; fi
  echo "========================================"
  [ "$fails" -eq 0 ]
}

# ---------------------------------------------------------------------------
cmd_ech() {
  XBD_PREFIX="$XBD_PREFIX" python3 "$XBD_LIBDIR/echcli.py" "$@"
}

cmd_update() {
  need_root
  step "更新本项目组件"
  dim "  系统 Xray / xray.service / mihomo 不会被更新或重启"
  local dist; dist=$(xbd_dist_dir)
  if [ "$(cd "$dist" && pwd)" != "$(cd "$XBD_PREFIX" && pwd)" ]; then
    cp -a "$dist/lib/." "$XBD_LIB/" 2>/dev/null || true
    cp -a "$dist/lib/." "$XBD_LIBDIR/" 2>/dev/null || true
    cp -a "$dist/service/." "$XBD_SERVICE/" 2>/dev/null || true
    cp -a "$dist/scripts/." "$XBD_SCRIPTS/" 2>/dev/null || true
    cp -a "$dist/docs/." "$XBD_PREFIX/docs/" 2>/dev/null || true
    [ -f "$dist/VERSION" ] && cp "$dist/VERSION" "$XBD_PREFIX/VERSION"
    install -m 0755 "$dist/bin/xbd" "$XBD_PREFIX/bin/xbd" 2>/dev/null || true
    ok "已同步项目文件"
  else
    ok "已在目标目录内运行，跳过自我拷贝"
  fi
  chmod 0755 "$XBD_SCRIPTS"/*.sh "$XBD_LIB"/*.py "$XBD_DIST/lib"/*.py 2>/dev/null || true
  local u
  for u in "$XBD_U_XRAY" "$XBD_U_SHARE" "$XBD_U_CHROMIUM" "$XBD_U_PANEL" "$XBD_U_HEALTH" "$XBD_U_TIMER"; do
    install -m 0644 "$XBD_SERVICE/$u" "/etc/systemd/system/$u"
  done
  systemctl daemon-reload
  if unit_active "$XBD_U_XRAY"; then
    systemctl restart "$XBD_U_XRAY"
    sleep 2
    if unit_active "$XBD_U_CHROMIUM"; then
      systemctl restart "$XBD_U_CHROMIUM" 2>/dev/null || true
    fi
  fi
  ok "更新完成"
  info "如需更新 Xray 内核: xbd xray update"
}

cmd_uninstall() {
  need_root
  local yes=0
  [ "${1:-}" = "--yes" ] && yes=1

  # 安全闸：systemd 单元名是全系统共享的，不随 XBD_PREFIX 变化。
  # 用自定义前缀（测试/多实例）时如果照常卸载，会删掉**生产环境**的单元。
  # 这个坑真实踩过：测试用 /tmp/rtest/install 前缀，把生产的 6 个单元删了。
  if [ "$XBD_PREFIX" != "/opt/xray-browser-dialer" ]; then
    warn "当前使用自定义前缀: $XBD_PREFIX"
    warn "systemd 单元名与主安装共用，卸载会影响主安装"
    info ""
    info "如需清理这个测试安装，请手动删除目录即可："
    info "  rm -rf $XBD_PREFIX"
    info ""
    info "若确实要卸载主安装，请用默认前缀运行："
    info "  /opt/xray-browser-dialer/bin/xbd uninstall"
    return 1
  fi
  step "将要删除的内容"
  local items=() u
  for u in "$XBD_U_XRAY" "$XBD_U_SHARE" "$XBD_U_CHROMIUM" "$XBD_U_PANEL" "$XBD_U_HEALTH" "$XBD_U_TIMER"; do
    [ -f "/etc/systemd/system/$u" ] && items+=("/etc/systemd/system/$u")
  done
  [ -d "$XBD_PREFIX" ] && items+=("$XBD_PREFIX/")
  [ ${#items[@]} -eq 0 ] && { warn "没有发现本项目的文件"; return 0; }
  for i in "${items[@]}"; do info "  - $i"; done
  echo
  ok "以下内容不会被删除:"
  dim "  /etc/xray, /usr/local/etc/xray, /usr/local/bin/xray, xray.service,"
  dim "  mihomo 配置, 其它用户服务, 防火墙与路由"
  if [ "$yes" -ne 1 ]; then
    echo; read -r -p "确认删除以上 ${#items[@]} 项？(yes/no) " ans
    [ "$ans" = "yes" ] || { warn "已取消"; return 1; }
  fi
  step "执行卸载"
  systemctl disable --now "$XBD_U_TIMER" "$XBD_U_PANEL" "$XBD_U_CHROMIUM" "$XBD_U_XRAY" 2>/dev/null || true
  for i in "${items[@]}"; do case "$i" in /etc/*) rm -f "$i" ;; esac; done
  systemctl daemon-reload
  ok "已移除 systemd 单元"
  rm -rf "$XBD_PREFIX"
  ok "已删除 $XBD_PREFIX"
}


# ---------------------------------------------------------------------------
# 方案 C：显式代理 —— 让本机进程（docker / apt / curl）用上我们的代理
# ---------------------------------------------------------------------------
# 为什么需要：docker 的 HTTP_PROXY 只接受 http:// 与 https://，不认 socks5://。
# 因此 Xray 除了 LAN 的 SOCKS5，还额外在回环上开一个 HTTP 代理。
#
# 接管原则：**改配置，不新增冲突配置**。
# 本机可能已经有别的服务（mihomo / 发行版脚本 / 手工配置）接管了系统代理。
# 我们再丢一份 /etc/profile.d/proxy.sh 进去就是两份互相打架的配置：profile.d 按
# 字典序 source，后者胜出，谁覆盖谁完全取决于文件名，出问题极难排查。
# 所以 on 时先探测"谁在接管"：探测到就**就地改写那一份**，并在 off 时按备份还原。
XBD_PROFILE_FILE="/etc/profile.d/proxy.sh"
XBD_DOCKER_PROXY="/etc/systemd/system/docker.service.d/http-proxy.conf"
XBD_ENV_FILE="/etc/environment"
XBD_PROXY_STATE="/var/lib/xbd-proxy"   # on 时备份原文件 + 记录归属，供 off 精确还原

xbd_proxy_url_http() { printf 'http://127.0.0.1:%s' "$XBD_PORT_HTTP"; }

# 代理变量行（shell / /etc/environment / systemd drop-in 三种写法都算）
XBD_PX_RE='^[[:space:]]*(export[[:space:]]+|unset[[:space:]]+|Environment=)?"?(http_proxy|https_proxy|HTTP_PROXY|HTTPS_PROXY|all_proxy|ALL_PROXY)"?='
XBD_PX_UNSET_RE='^[[:space:]]*unset[[:space:]]+"?(http_proxy|https_proxy|HTTP_PROXY|HTTPS_PROXY|all_proxy|ALL_PROXY)"?[[:space:]]*$'

# 这份文件是否真的设置了代理（只写 no_proxy 不算接管）
_xbd_proxy_claims() {
  [ -f "$1" ] || return 1
  grep -qE "$XBD_PX_RE|$XBD_PX_UNSET_RE" "$1" 2>/dev/null
}

# 本机**别人**的代理接管点，输出 <style>|<file>，style ∈ sh|env|systemd。
# 输出顺序即生效顺序（profile.d 按字典序 source，后者覆盖前者）。
xbd_proxy_owners() {
  local f
  for f in /etc/profile.d/*.sh; do
    [ -e "$f" ] || continue
    [ "$f" = "$XBD_PROFILE_FILE" ] && continue
    _xbd_proxy_claims "$f" && printf 'sh|%s\n' "$f"
  done
  _xbd_proxy_claims /etc/environment && printf 'env|/etc/environment\n'
  for f in /etc/systemd/system/docker.service.d/*.conf; do
    [ -e "$f" ] || continue
    [ "$f" = "$XBD_DOCKER_PROXY" ] && continue
    _xbd_proxy_claims "$f" && printf 'systemd|%s\n' "$f"
  done
  return 0
}

# 可能携带本机代理配置的文件：别人的接管点 + 我们自己的落点
xbd_proxy_files() {
  xbd_proxy_owners
  [ -f "$XBD_PROFILE_FILE" ] && printf 'sh|%s\n' "$XBD_PROFILE_FILE"
  [ -f "$XBD_DOCKER_PROXY" ] && printf 'systemd|%s\n' "$XBD_DOCKER_PROXY"
  [ -f /etc/environment ]    && printf 'env|/etc/environment\n'
  return 0
}

# $1=style $2=port → 哪些文件正在带我们的代理（一行一个路径）
_xbd_proxy_hits() {
  local lines st f
  lines="$(xbd_proxy_files || true)"
  while IFS='|' read -r st f; do
    [ "$st" = "$1" ] || continue
    grep -q "127.0.0.1:$2" "$f" 2>/dev/null && printf '%s\n' "$f"
  done <<< "$lines"
  return 0
}

# $1=style $2=port → 给人看的一句话
_xbd_proxy_where() {
  local hit
  hit="$(_xbd_proxy_hits "$1" "$2" | paste -sd, -)"
  if [ -n "$hit" ]; then printf '已配置（%s）' "$hit"; else printf '未配置'; fi
}

# 给面板用：本机接管的**真实**状态（含"接管点其实在别人那份配置里"的情况）
xbd_proxy_json() {
  xbd_load_ports
  local p="$XBD_PORT_HTTP" sh_hit dk_hit ev_hit
  sh_hit="$(_xbd_proxy_hits sh      "$p" | paste -sd' ' -)"
  dk_hit="$(_xbd_proxy_hits systemd "$p" | paste -sd' ' -)"
  ev_hit="$(_xbd_proxy_hits env     "$p" | paste -sd' ' -)"
  printf '{"enabled":%s,"shell":"%s","docker":"%s","environment":"%s","owners":%s}\n' \
    "$([ -n "$sh_hit$dk_hit$ev_hit" ] && echo true || echo false)" \
    "$sh_hit" "$dk_hit" "$ev_hit" "$(xbd_proxy_owners | wc -l)"
}

# 归属登记：第一次接管某个文件时把原文备份下来（off 据此还原，而不是删掉别人的配置）
_xbd_proxy_record() {   # $1=created|edited $2=file
  local act="$1" f="$2" prev
  mkdir -p "$XBD_PROXY_STATE"
  prev="$(_xbd_proxy_recorded "$f")"
  if [ -n "$prev" ]; then
    [ "$prev" = "$act" ] || warn "$f 已登记为 $prev，保留最早的备份不动"
    return 0
  fi
  if [ "$act" = edited ]; then
    cp -a "$f" "$XBD_PROXY_STATE/$(printf '%s' "$f" | tr '/' '_').orig" || return 1
  fi
  printf '%s\t%s\n' "$act" "$f" >> "$XBD_PROXY_STATE/manifest"
}

_xbd_proxy_recorded() {   # $1=file → created|edited|空
  [ -s "$XBD_PROXY_STATE/manifest" ] || return 0
  awk -F'\t' -v p="$1" '$2==p{print $1; exit}' "$XBD_PROXY_STATE/manifest"
  return 0
}

# 就地改写别人的配置：代理变量行按我们的值重写，缺的变量在同一份文件里补齐
# （缺 http_proxy 却有 HTTP_PROXY 的程序不少，补齐才是一次完整的接管），
# 其余内容 —— 注释、unset、别的 export、段落结构 —— 原样保留。
# 补齐块插在**最后一条**代理变量之后，不追加到文件末尾：systemd drop-in 的
# 末尾可能已经在别的段落（[Unit]/[Install]）里，追加过去就不是给 [Service] 了。
# 用 cat > 回写而非 mv，保持 inode / 权限 / 属主不变。
_xbd_proxy_rewrite() {   # $1=file $2=style(sh|env|systemd) $3=http $4=no_proxy
  local f="$1" tmp
  tmp="$(mktemp)" || return 1
  awk -v style="$2" -v http="$3" -v nop="$4" '
    BEGIN {
      split("http_proxy https_proxy HTTP_PROXY HTTPS_PROXY all_proxy no_proxy NO_PROXY", ord, " ")
      for (i = 1; i <= 7; i++) V[ord[i]] = 1
    }
    function render(n, v) {
      v = (n == "no_proxy" || n == "NO_PROXY") ? nop : http
      if (style == "systemd")  out = "Environment=\"" n "=" v "\""
      else if (style == "env") out = n "=\"" v "\""
      else                     out = "export " n "=\"" v "\""
      return out
    }
    function emit_missing(   i, n, gap) {
      for (i = 1; i <= 7; i++) {
        n = ord[i]
        if (n in seen) continue
        if (!gap) { print ""; print "# 以下由 xbd proxy on 补齐（原配置只设了部分代理变量）"; gap = 1 }
        print render(n)
      }
    }
    {
      if ($0 ~ /^[ \t]*#/) { lines[NR] = $0; next }
      t = $0
      sub(/^[ \t]+/, "", t); sub(/^(export|unset)[ \t]+/, "", t)
      sub(/^Environment=/, "", t); sub(/^"/, "", t)
      n = t; sub(/[^A-Za-z_].*$/, "", n)
      if (n in V && (t == n || t ~ ("^" n "="))) {
        lines[NR] = render(n); seen[n] = 1; last = NR; next
      }
      lines[NR] = $0
    }
    END {
      for (i = 1; i <= NR; i++) {
        print lines[i]
        if (i == last) emit_missing()
      }
      if (last == 0) emit_missing()
    }' "$f" > "$tmp" || { rm -f "$tmp"; return 1; }
  cat "$tmp" > "$f" || { rm -f "$tmp"; return 1; }
  rm -f "$tmp"
}

_xbd_proxy_new_sh() {     # $1=file $2=http $3=no_proxy
  cat > "$1" <<EOF
# 由 xbd proxy on 生成 —— 本机进程的显式代理，指向本项目的 Xray。
# 关闭: xbd proxy off
export http_proxy="$2"
export https_proxy="$2"
export HTTP_PROXY="$2"
export HTTPS_PROXY="$2"
export all_proxy="$2"
export no_proxy="$3"
export NO_PROXY="$3"
EOF
  chmod 0644 "$1"
}

_xbd_proxy_new_docker() { # $1=file $2=http $3=no_proxy
  # 变量集合与 _xbd_proxy_rewrite 补齐的完全一致：
  # 「别人接管 → 我们改写」和「没人接管 → 我们新建」必须得到同一份效果。
  mkdir -p "$(dirname "$1")"
  cat > "$1" <<EOF
# 由 xbd proxy on 生成 —— docker 守护进程拉镜像走本项目的 Xray。
# 关闭: xbd proxy off
[Service]
Environment="http_proxy=$2"
Environment="https_proxy=$2"
Environment="HTTP_PROXY=$2"
Environment="HTTPS_PROXY=$2"
Environment="all_proxy=$2"
Environment="no_proxy=$3"
Environment="NO_PROXY=$3"
EOF
  chmod 0644 "$1"
}

# 处理一个落点：本机已有接管 → 就地改那一份；没有 → 才新建我们自己的文件。
# $1=style $2=新建时的文件名（空 = 只改不建）$3=写入器 $4=http $5=no_proxy
_xbd_proxy_slot() {
  local style="$1" dflt="$2" writer="$3" owner
  owner="$({ xbd_proxy_owners || true; } | awk -F'|' -v s="$style" '$1==s{print $2}' | tail -n1)"
  if [ -n "$owner" ]; then
    if [ -n "$dflt" ] && [ -f "$dflt" ] && [ "$dflt" != "$owner" ]; then
      rm -f "$dflt" && info "已移除旧版留下的 $dflt（两份配置会互相覆盖）"
    fi
    ok "检测到本机已被接管: $owner —— 就地改这份配置，不新增文件"
    _xbd_proxy_record edited "$owner" || { bad "备份失败，已放弃改写: $owner"; return 1; }
    _xbd_proxy_rewrite "$owner" "$style" "$4" "$5" || { bad "改写失败: $owner"; return 1; }
    ok "已改写 $owner"
    return 0
  fi
  [ -n "$dflt" ] || return 0    # 只改不建（/etc/environment 不做代理就不管它）
  _xbd_proxy_record created "$dflt" || return 1
  "$writer" "$dflt" "$4" "$5"
  ok "已写 $dflt"
}

cmd_proxy() {
  local op="${1:-status}"
  case "$op" in
    on|enable)   xbd_proxy_on ;;
    off|disable|clean) xbd_proxy_clean ;;
    status|"")   xbd_proxy_status ;;
    json)        xbd_proxy_json ;;
    -h|--help)   info "用法: xbd proxy <status|clean>   查看入口 / 清理旧版接管留下的系统配置" ;;
    *) die "未知操作: $op" ;;
  esac
}

xbd_proxy_status() {
  xbd_load_ports
  printf '  HTTP 代理入口:    127.0.0.1:%s  %s\n' "$XBD_PORT_HTTP" \
    "$(port_listening_tcp "$XBD_PORT_HTTP" && echo LISTENING || echo 未监听)"
  printf '  LAN SOCKS5 入口:  %s:%s  %s\n' "$XBD_LISTEN_ADDR" "$XBD_PORT_NORMAL" \
    "$(port_listening_tcp "$XBD_PORT_NORMAL" && echo LISTENING || echo 未监听)"
  printf '  LAN HTTP 入口:    %s:%s  %s\n' "$XBD_LISTEN_ADDR" "$XBD_PORT_LAN_HTTP" \
    "$(port_listening_tcp "$XBD_PORT_LAN_HTTP" && echo LISTENING || echo 未监听)"
  printf '  shell 代理:       %s\n' "$(_xbd_proxy_where sh "$XBD_PORT_HTTP")"
  printf '  docker 代理:      %s\n' "$(_xbd_proxy_where systemd "$XBD_PORT_HTTP")"
  printf '  /etc/environment: %s\n' "$(_xbd_proxy_where env "$XBD_PORT_HTTP")"
  local own; own="$(xbd_proxy_owners || true)"
  if [ -n "$own" ]; then
    info "  本机另有代理接管点（on 时会就地改它，不新增文件）:"
    while IFS='|' read -r st f; do info "    [$st] $f"; done <<< "$own"
  else
    printf '  本机另有代理接管点: 无\n'
  fi
}

xbd_proxy_on() {
  # 「接管本机」已下线。
  #
  # 原来这个功能会往 /etc/profile.d/proxy.sh 和 docker.service.d 写代理变量，
  # 让本机进程（shell / docker / apt / curl）默认走 Xray。去掉的理由有两个：
  #
  #   一是安全：接管要写系统级配置，改一次影响全机，出问题很难查。
  #   二是耦合：为了写 docker 的代理，systemd 单元的 ReadWritePaths 里就得开
  #   /etc/systemd/system/docker.service.d —— 而没装 Docker 的机器上这个目录
  #   不存在，systemd 遇到不存在的 ReadWritePaths 会放弃整个单元，面板根本
  #   起不来（226/NAMESPACE）。为了一个可选功能，把主功能绑架了。
  #
  # 端口本身不动：PORT_HTTP / PORT_LAN_HTTP 仍是 Xray 的正常入口，想要的人
  # 自己 export 或在客户端里指定就行。不自动改系统，是留给用户的选择。
  need_root 2>/dev/null || true
  xbd_load_ports
  warn "「接管本机」已下线：本客户端不再自动修改系统代理配置。"
  info ""
  info "  仍可用的入口（按需自己指定，不会自动写进系统）："
  info "    SOCKS5  $XBD_LISTEN_ADDR:$XBD_PORT_NORMAL"
  info "    HTTP    $XBD_LISTEN_ADDR:$XBD_PORT_LAN_HTTP   (局域网)"
  info "    HTTP    127.0.0.1:$XBD_PORT_HTTP              (仅本机)"
  info ""
  info "  单个命令临时走代理："
  info "    curl -x http://127.0.0.1:$XBD_PORT_HTTP https://example.com"
  info ""
  if [ -f "$XBD_PROFILE_FILE" ] || [ -f "$XBD_DOCKER_PROXY" ]; then
    info "  检测到本机还有旧版接管留下的配置，执行 'xbd proxy clean' 可清理。"
  fi
}

xbd_proxy_clean() {
  # 清理旧版接管写进系统的代理配置。
  #
  # 用 xbd-proxy 那套原有的备份/归属记录来判断，而不是靠"文件内容像不像我们的"。
  # 记录里区分了 created（这文件是我们新建的，删掉即可）和 edited（用户原本就有
  # 我们只改了里面几行，删掉会连用户自己的设置一起弄丢 —— 要从 .orig 还原）。
  # 没有记录的（别的程序写的、或被用户改过）一律不动，只提示。
  need_root
  xbd_load_ports
  step "清理旧版接管配置"
  local n=0 f st orig
  for f in "$XBD_PROFILE_FILE" "$XBD_DOCKER_PROXY" "$XBD_ENV_FILE"; do
    [ -e "$f" ] || continue
    orig="$XBD_PROXY_STATE/$(printf '%s' "$f" | tr '/' '_').orig"
    st="$(_xbd_proxy_recorded "$f")"
    case "$st" in
      created) rm -f "$f"; ok "  已删除 $f（这文件是接管时新建的）"; n=$((n+1)) ;;
      edited)
        if [ -f "$orig" ]; then
          mv "$orig" "$f"; ok "  已还原 $f（接管前的原内容）"; n=$((n+1))
        else
          warn "  $f 曾被接管改写过，但原文件备份不在（$orig），已跳过，请人工确认"
        fi ;;
      *)
        if grep -q "127.0.0.1:$XBD_PORT_HTTP" "$f" 2>/dev/null; then
          warn "  $f 指向本项目端口但没有接管记录（可能是别处手工设的），已跳过，请人工确认"
        else
          warn "  $f 不带本项目代理，已跳过（不是接管留下的）"
        fi ;;
    esac
  done
  [ -s "$XBD_PROXY_STATE/manifest" ] && rm -f "$XBD_PROXY_STATE/manifest"
  systemctl daemon-reload 2>/dev/null || true
  if [ "$n" -eq 0 ]; then
    ok "  没有需要清理的配置"
  else
    ok "  清理完成（$n 处）。"
  fi
  info "  注意：清理只影响之后的 shell。当前这个终端若还带着 http_proxy 等变量，"
  info "        需手动 unset，或重新登录一次。"
}

# Xray 内核版本与更新（之前 cmd_update 只同步项目文件，从不更新二进制）
cmd_xray() {
  local op="${1:-version}"
  case "$op" in
    version) python3 "$XBD_LIBDIR/xrayup.py" version ;;
    check)   python3 "$XBD_LIBDIR/xrayup.py" check ;;
    update|upgrade)
      need_root
      step "更新 Xray 内核"
      dim "  只更新本项目副本 $XBD_XRAY，不碰系统 Xray"
      python3 "$XBD_LIBDIR/xrayup.py" update || return 1
      systemctl restart "$XBD_U_XRAY"
      sleep 3
      unit_active "$XBD_U_XRAY" && ok "$XBD_U_XRAY 已重启" || { bad "Xray 重启失败"; journalctl -u "$XBD_U_XRAY" -n 12 --no-pager; return 1; }
      if unit_active "$XBD_U_CHROMIUM"; then
        systemctl restart "$XBD_U_CHROMIUM" 2>/dev/null || true
        info "已同步重启 Chromium（Xray 重启会换 CSRF token）"
      fi
      ;;
    -h|--help|"") info "用法: xbd xray <version|check|update>" ;;
    *) die "未知操作: $op" ;;
  esac
}

# 导出连接配置到固定文件，方便直接复制
cmd_export() {
  xbd_load_ports
  mkdir -p "$XBD_GENERATED"
  local host="$XBD_LISTEN_ADDR"
  local name="LAN"
  if [ -e "$XBD_NODES/current" ]; then
    name=$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1])).get("name","LAN"))' "$(readlink -f "$XBD_NODES/current")" 2>/dev/null | tr -cd 'A-Za-z0-9._-' || echo LAN)
    [ -n "$name" ] || name="LAN"
  fi

  local yaml="$XBD_GENERATED/mihomo.yaml"
  local links="$XBD_GENERATED/links.txt"
  local envf="$XBD_GENERATED/env.sh"

  cat > "$yaml" <<EOF
# 由 xbd export 生成 —— 复制到需要代理的设备
# 生成时间: $(date '+%Y-%m-%d %H:%M:%S')

proxies:
  - name: "${name}-SOCKS5"
    type: socks5
    server: $host
    port: $XBD_PORT_NORMAL
    udp: true
  - name: "${name}-HTTP"
    type: http
    server: $host
    port: $XBD_PORT_LAN_HTTP
EOF

  cat > "$links" <<EOF
# 代理链接 —— 生成时间 $(date '+%Y-%m-%d %H:%M:%S')
SOCKS5          socks5://$host:$XBD_PORT_NORMAL
HTTP            http://$host:$XBD_PORT_LAN_HTTP
（两个入口都由同一个 Xray 实例服务，所有节点通用；本机进程用 127.0.0.1:$XBD_PORT_HTTP，仅回环）
EOF

  cat > "$envf" <<EOF
# source 这个文件即可让当前 shell 走代理
export http_proxy="http://$host:$XBD_PORT_LAN_HTTP"
export https_proxy="http://$host:$XBD_PORT_LAN_HTTP"
export all_proxy="socks5://$host:$XBD_PORT_NORMAL"
export no_proxy="127.0.0.1,localhost,::1,192.168.0.0/16,10.0.0.0/8"
EOF
  chmod 0644 "$yaml" "$links" "$envf"

  ok "已导出到 $XBD_GENERATED/"
  printf '  %-28s %s\n' "Mihomo 配置" "$yaml"
  printf '  %-28s %s\n' "代理链接" "$links"
  printf '  %-28s %s\n' "环境变量" "$envf"
  info ""
  info "服务器上直接看: cat $links"
}

# v2.2: 导入节点后自动探测并固定服务端证书指纹。
# 背景：Xray 26.x 移除了 allowInsecure（mihomo 的 skip-cert-verify），
# 自签/老格式证书的节点导入即“连不上”。以前要手动执行 xbd cert <编号>，
# 现在导入时自动做掉 —— 加进来就能用。
# 失败不阻断导入（warn 后继续），因为“能用”还取决于服务端是否在线。
# 证书探针：**优先用编译好的二进制**，没有才编译一次并缓存到 runtime/。
#
# 为什么非缓存不可（实测数据）：
#   `go run .` 冷构建要 ~114 秒（quic-go 全量编译，本机 aarch64 实测），
#   而面板的导入动作超时是 120 秒 —— 只差 6 秒。于是"首次导入"经常被杀在半路：
#   节点文件已经落盘、指纹还没写 → 用户看到导入成功，节点却必然连不上
#   （Xray 26.x 没有 allowInsecure，证书 CN-only 直接 CRYPTO_ERROR）。
#   缓存后是毫秒级，彻底离开超时窗口。二进制放 runtime/（发布包与 GitHub 都不含它）。
_xbd_cert_probe() {   # $1=addr $2=port $3=sni → 探针输出（stdout+stderr）
  local addr="$1" port="$2" sni="$3"
  local dir="$XBD_DIST/tools/certprobe"
  local bin="$XBD_RUNTIME/certprobe"
  [ -d "$dir" ] || { warn "缺少工具目录 $dir"; return 1; }
  command -v go >/dev/null 2>&1 || { warn "机器缺少 go 工具链（apt install golang-go 后可重试）"; return 1; }
  if [ ! -x "$bin" ]; then
    info "  首次使用需编译证书探针（约 1-2 分钟，只编译这一次）…"
    mkdir -p "$XBD_RUNTIME"
    ( cd "$dir" && GOFLAGS=-mod=mod https_proxy="${XBD_HTTP_PROXY:-}" go build -o "$bin" . ) >/dev/null 2>&1 \
      || { warn "证书探针编译失败（检查 go 工具链与网络）"; return 1; }
  fi
  "$bin" "$addr" "$port" "$sni" 2>&1
}

_xbd_autopin_cert() {
  local path="$1"
  [ -f "$path" ] || return 0
  local need
  need=$(python3 - "$path" <<'PYIN'
import json, sys
d = json.load(open(sys.argv[1]))
print(1 if (d.get("allow_insecure") or d.get("skip_cert_verify")) and not d.get("pinned_cert_sha256") else 0)
PYIN
)
  [ "$need" = "1" ] || return 0

  local addr port sni
  addr=$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1])).get("address",""))' "$path")
  port=$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1])).get("port","443"))' "$path")
  sni=$(python3 -c 'import json,sys;d=json.load(open(sys.argv[1]));print(d.get("sni") or d.get("address",""))' "$path")

  step "自动探测服务端证书（替代已移除的 allowInsecure）"
  info "  目标: [$addr]:$port  SNI=$sni"
  if ! command -v go >/dev/null 2>&1; then
    warn "未能自动固定证书：机器缺少 go 工具链（安装 golang-go 后可手动 xbd cert <编号> 重试）"
    return 0
  fi
  local out fp
  if ! out=$(_xbd_cert_probe "$addr" "$port" "$sni"); then
    warn "证书探测失败（节点可能离线/非TLS）；可手动 xbd cert <编号> 重试"
    return 0
  fi
  printf '%s
' "$out" | sed 's/^/  /'
  fp=$(printf '%s' "$out" | grep -oE '[0-9a-f]{64}' | awk 'NR==1')
  [ -n "$fp" ] || { warn "未取到证书指纹；可手动 xbd cert <编号> 重试"; return 0; }

  python3 - "$path" "$fp" <<'PYIN'
import json, sys
p, fp = sys.argv[1], sys.argv[2]
d = json.load(open(p))
d["pinned_cert_sha256"] = fp
json.dump(d, open(p, "w"), ensure_ascii=False, indent=2)
print(f"  已自动固定 pinned_cert_sha256: {fp[:32]}...")
PYIN
  info "  导入即用，无需手动固定（服务端换签后需重新固定）"
  # 如果补的正是**当前节点**，必须立刻重启：运行中的 Xray 用的是上一次生成的配置，
  # 指纹写进节点文件它并不知道 —— 实测踩过：面板导入修好了节点文件，但服务还在用
  # 旧配置，出口一直是 000，用户以为"修了还是不行"。
  if [ "$(basename "$(readlink -f "$XBD_NODES/current" 2>/dev/null || true)" 2>/dev/null)" = "$(basename "$path")" ]; then
    info "  这是当前节点，重启 Xray 让指纹生效…"
    _xbd_sync_xray_with_node force || warn "重启失败，请手动执行: xbd restart"
  fi
  return 0
}

# 取服务端证书指纹并写进节点（自签证书节点的正确解法）
# Xray 26.x 移除了 allowInsecure，替代方案就是 pinnedPeerCertSha256。
cmd_cert() {
  local t="${1:-}"
  # 批量补指纹：所有「声明跳过证书校验、但还没有指纹」的节点。
  # 用途：修历史遗留 —— 导入时被杀在半路、或服务端换签后指纹失效。
  if [ "$t" = "--missing" ] || [ "$t" = "--all" ]; then
    local f need n=0 rc=0
    for f in "$XBD_NODES"/node-*.json; do
      [ -e "$f" ] || continue
      need=$(python3 -c 'import json,sys
d=json.load(open(sys.argv[1]))
print(1 if (d.get("allow_insecure") or d.get("skip_cert_verify")) and not d.get("pinned_cert_sha256") else 0)' "$f" 2>/dev/null || echo 0)
      [ "$need" = "1" ] || continue
      n=$((n+1))
      cmd_cert "$(basename "$f")" || rc=1
    done
    if [ "$n" -eq 0 ]; then
      ok "所有需要指纹的节点都已固定（无需处理）"
    else
      info "共处理 $n 个节点"
    fi
    return $rc
  fi
  [ -n "$t" ] || die "用法: xbd cert <编号|文件名> | --missing（批量补齐缺失的指纹）"
  local path
  if [[ "$t" =~ ^[0-9]+$ ]]; then
    path=$(xbd_node_path "$t")
  else
    path=$(xbd_node_path "$t")
  fi
  [ -e "${path:-}" ] || die "找不到节点: $t"

  local addr port sni proto
  addr=$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1])).get("address",""))' "$path")
  port=$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1])).get("port",443))' "$path")
  sni=$(python3 -c 'import json,sys;d=json.load(open(sys.argv[1]));print(d.get("sni") or d.get("address",""))' "$path")
  proto=$(python3 -c 'import json,sys;print(json.load(open(sys.argv[1])).get("protocol",""))' "$path")

  step "取服务端证书指纹"
  info "  节点: $(basename "$path")"
  info "  目标: [$addr]:$port  SNI=$sni"
  local out
  out=$(_xbd_cert_probe "$addr" "$port" "$sni") || die "证书探测失败（节点离线/非 TLS？）"
  printf '%s\n' "$out" | sed 's/^/  /'

  local fp
  # 输出形如 "      SHA256 =4cdbca..."（等号前后可能没空格），所以只匹配 64 位十六进制
  fp=$(printf '%s' "$out" | grep -oE '[0-9a-f]{64}' | awk 'NR==1')
  [ -n "$fp" ] || die "未能取到证书指纹（节点可能不响应 QUIC/TLS）"

  python3 - "$path" "$fp" <<'PY'
import json, sys
p, fp = sys.argv[1], sys.argv[2]
d = json.load(open(p))
d["pinned_cert_sha256"] = fp
json.dump(d, open(p, "w"), ensure_ascii=False, indent=2)
print(f"  已写入 pinned_cert_sha256: {fp[:32]}...")
PY
  ok "证书已固定。执行 xbd apply && xbd restart 生效"
  warn "注意：服务端证书换签后该哈希会失效，届时重新执行 xbd cert 即可"
}

cmd_usage() { xbd_usage; }

xbd_usage() {
  cat <<EOF
Xray Client Web Manager v$XBD_VERSION
唯一 Xray 实例（SOCKS + HTTP 两入口）+ Browser Dialer 按节点自动生效

用法: xbd <命令> [参数]

  安装与基础
    install [--no-start] [--vless <uri>]   安装（幂等）
    update                                 更新本项目脚本
    xray version|check|update              查看/检查/更新 Xray 内核
    uninstall                              安全卸载（先列清单）

  节点（共享资产；是否需要浏览器拨号由服务器按节点自动决定）
    node add "<uri|json|yaml>"             导入节点（支持多行 / 多协议）
    node simple [socks|http] [地址] [端口]  简易出站：把本机/局域网里别的内核当上游
                                           例: xbd node simple socks 127.0.0.1 1080
    node sub <订阅URL>                     导入订阅
    node list                              节点列表（含 Xray / Browser Dialer 两种能力）
    node use <编号>                        切换当前节点
    node check [编号]                      能力检查
    node latency [编号]                    延时测试（真实请求）
    node remove <编号>                     删除节点

  服务（唯一实例，同时提供 SOCKS 与 HTTP）
    start                                  启动 Xray + 面板
    stop [--all]                           停止 Xray（--all 连面板一起停）
    restart                                重启 Xray（会自动同步重启 Chromium）
    dialer on|off|toggle|status            启动/停掉 Chromium（Browser Dialer 的运行时依赖）
    browser [install]                      浏览器运行时：装没装 / 版本 / 一键安装
                                           （默认不自动装：几百 MB，且 Debian 上可能是 snap 壳）
    apply                                  重新生成配置
    port [类型] [值]                       查看/修改端口（normal/http/lan-http/channel/panel/api/addr）
    ports check|fix|verify                 端口冲突检查 / 自动重新分配 / 校验浏览器两端接上

  本机上网 / 局域网接入
    proxy on|off|status                    让本机进程（docker/apt/curl）走我们的代理
                                           （发现别的服务已接管系统代理时，就地改那一份）
    局域网设备：在设备的代理设置里填「本机 IP:1080(SOCKS5) / :10809(HTTP)」即可，
                不需要本机做任何改动（透明网关模式已移除，见 docs/mode3-lan-gateway/）

  多出站 / 配置分发 / 菜单
    multi status|on|off                    多出站开关（默认关：单节点模式）。
                                           开启后所有节点同时在线，按权重分流；
                                           想要的时候再开，别默认打开。
    family [auto|v4|v6]                    出站地址族（默认 auto=历史行为：
                                           直连走 IPv4、DNS 按连通性选）。
                                           双栈机器上某一边不通时才需要改。
    share new|list|url|off                  配置分发：生成带令牌的分享链接，
                                           别人扫码/导入即可拿到你的节点配置。
                                           分享服务只在开启时占用一个端口。
    menu                                   交互式菜单（推荐：日常操作用这个）

  状态与诊断
    status [--quick]                       状态（含当前节点实际走哪条 TLS 路径）
    diagnose [--quick]                     全面诊断
    panel [status|restart|stop]            网页面板：地址与令牌 / 重启 / 停掉
    export                                 导出连接配置到 generated/（方便复制）
    cert <编号|--missing>                  取服务端证书指纹并固定（自签证书节点用；--missing 批量补齐）
    ech                                    验证 Chromium 原生 ECH

  selftest                                 运行内置自检
EOF
}

# ---------------------------------------------------------------------------
xbd_main() {
  # 运行期脚本目录：多文件版=项目根，自解压版=xbd-dist
  XBD_LIBDIR="$(xbd_dist_dir)/lib"
  export XBD_LIBDIR
  local cmd="${1:-}"; shift || true
  case "$cmd" in
    install)    cmd_install "$@" ;;
    update)     cmd_update "$@" ;;
    uninstall)  cmd_uninstall "$@" ;;
    node)       cmd_node "$@" ;;
    start)      cmd_start "$@" ;;
    stop)       cmd_stop "$@" ;;
    restart)    cmd_restart "$@" ;;
    dialer)     cmd_dialer "$@" ;;
    apply)      cmd_apply "$@" ;;
    port)       cmd_port "$@" ;;
    ports)      cmd_ports "$@" ;;
    status)     cmd_status "$@" ;;
    diagnose)   cmd_diagnose "$@" ;;
    panel)      cmd_panel "$@" ;;
    browser)    case "${1:-status}" in
                  install) shift; xbd_browser_install "$@" ;;
                  *) xbd_browser_status ;;
                esac ;;
    ech)        cmd_ech "$@" ;;
    proxy)      cmd_proxy "$@" ;;
    xray)       cmd_xray "$@" ;;
    export)     cmd_export "$@" ;;
    cert)       cmd_cert "$@" ;;
    selftest)   cmd_selftest "$@" ;;
    share)      cmd_share "$@" ;;
    menu)       cmd_menu "$@" ;;
    multi)      cmd_multi "$@" ;;
    family)     cmd_family "$@" ;;
    "")
      # 直接敲 xbd 时: 在终端里进面板, 管道/脚本里给用法。
      # 理由: 站在服务器上打开客户端, 九成是想看状态或切节点; 而脚本里
      # `xbd`（比如 CI 里跑一下）必须拿到可解析的文本, 不能被菜单卡住。
      if [ -t 0 ] && [ -t 1 ]; then cmd_menu
      else xbd_usage; fi ;;
    -h|--help|help) xbd_usage ;;
    *) xbd_usage; die "未知命令: $cmd" ;;
  esac
}

# ================================================================
# 客户端面板 — SSH 里的菜单
#
# 为什么要有这个：功能其实一直都在（27 个子命令），但全是参数式的。想看一眼
# 现在用哪个节点，得先记得住 `xbd status`；想切节点，得记得 `xbd node use <编号>`。
# 菜单的价值不是"多一种入口"，而是让人不用记命令 —— 站在服务器上打开就是
# 眼前该做的几件事。
#
# 凡是面板里能做的，都转调已有的子命令，不另写一套逻辑。菜单和命令行
# 因此永远一致，不会出现"菜单改了、命令行没改"这种分叉。
# ================================================================
_mmenu() {
  local c
  while :; do
    clear 2>/dev/null || true
    _mmenu_header
    echo
    ui_sec "节点"
    ui_menu 1 "节点管理      列出 / 添加 / 切换 / 测速 / 删除"
    ui_menu 2 "分组管理      订阅归组 / 改名 / 整组删除"
    ui_menu 3 "浏览器拨号    逐节点开关（省内存，默认关）"
    echo
    ui_sec "服务"
    ui_menu 4 "服务控制      启动 / 停止 / 重启 / 状态"
    ui_menu 5 "端口设置      SOCKS / HTTP / 面板端口"
    ui_menu 6 "多出站        所有节点常驻，切换不断线"
    echo
    ui_sec "接入与分发"
    ui_menu 7 "配置分发      局域网设备用 URL 拉配置"
    ui_menu 8 "Web 面板      地址 / 令牌 / 开关"
    echo
    ui_sec "其它"
    ui_menu 9 "诊断          连不上时先看这个"
    ui_menu 0 "退出"
    echo
    ui_hint "直接回车 = 退出；命令行等价写法: xbd --help"
    printf "  %s请选择%s: " "$C_B" "$C_0"
    read -r c || return 0
    case "$c" in
      1) _mmenu_node ;;
      2) _mmenu_group ;;
      3) _mmenu_browser ;;
      4) _mmenu_service ;;
      5) _mmenu_port ;;
      6) _mmenu_multi ;;
      7) _mmenu_share ;;
      8) _mmenu_panel ;;
      9) xbd diagnose ;;
      0|"") return 0 ;;
      *) ui_invalid "$c" ;;
    esac
    _mmenu_pause
  done
}

# 面板顶部：一条标题 + 四行状态。
#
# 为什么不做成 cmd_status_text 那 12 行: 菜单每操作一步都会重画一次, 12 行状态
# 会把菜单顶到屏幕外。这里只留"打开就知道现在什么情况"的四项, 详细状态
# 用 xbd status。
_mmenu_header() {
  ui_title "Xray Client  v${XBD_VERSION:-?}"
  local st ver n cur panel_host panel_port
  st=$(systemctl is-active "$XBD_U_XRAY" 2>/dev/null || echo inactive)
  ver=$(xray_ver)
  n=$(ls "$XBD_NODES"/node-*.json 2>/dev/null | wc -l | tr -d ' ')
  # ★ 显示节点**真名**（JSON 里的 name），不是文件名。
  #   文件名形如 node-001-ccsmhysteria2-01.json，直接剥前缀显示出来是
  #   "001-ccsmhysteria2-01" —— 而用户在自己客户端里看到的是
  #   "🇺🇸 CCSmHysteria2-01"，两个名字对不上，切节点时会怀疑切错了。
  local curf; curf=$(current_node_file 2>/dev/null || true)
  if [ -n "$curf" ]; then
    cur=$(node_field "$curf" name 2>/dev/null || true)
    [ -n "$cur" ] || cur=$(basename "$curf" | sed 's/^node-//; s/\.json$//')
  else
    cur=""
  fi
  panel_host=$(cfg_get "$XBD_CONF/panel.env" PANEL_HOST 127.0.0.1)
  panel_port=$(cfg_get "$XBD_CONF/panel.env" PANEL_PORT 18090)

  if [ "$st" = "active" ]; then
    ui_kv "服务状态" "$(printf '%s● 运行中%s' "$C_G" "$C_0")"
  else
    ui_kv "服务状态" "$(printf '%s○ %s%s' "$C_Y" "$st" "$C_0")"
  fi
  ui_kv "内核版本" "${ver:-未知}"
  ui_kv "节点数量" "$n"
  ui_kv "当前节点" "${cur:-（未选择）}"
  ui_kv "网页面板" "http://$panel_host:$panel_port/"
}

_mmenu_pause() { ui_pause; }

# 顶部一行状态：不用进子菜单就知道现在是什么情况
_mmenu_status() {
  local st cur
  st=$(systemctl is-active "$XBD_U_XRAY" 2>/dev/null || echo inactive)
  cur=$(readlink "$XBD_NODES/current" 2>/dev/null | xargs -r basename | sed 's/^node-//; s/\.json$//')
  local n; n=$(ls "$XBD_NODES"/node-*.json 2>/dev/null | wc -l)
  if [ "$st" = "active" ]; then
    printf '  状态: \033[32m运行中\033[0m    节点: %s 个    当前: %s\n' "$n" "${cur:-未选择}"
  else
    printf '  状态: \033[31m%s\033[0m    节点: %s 个    当前: %s\n' "$st" "$n" "${cur:-未选择}"
  fi
}

_mmenu_node() {
  local c
  while :; do
    echo
    ui_title "节点管理"
    ui_sec "看与切"
    ui_menu 1 "列出全部节点        名字 / 地址 / 延迟 / 能力标签"
    ui_menu 2 "切换当前节点"
    ui_menu 3 "测速（全部节点）"
    echo
    ui_sec "添加"
    ui_menu 4 "粘贴导入            分享链接 / 订阅 / Xray JSON / Mihomo YAML"
    ui_menu 5 "导入订阅并命名成组"
    ui_menu 6 "简易 SOCKS/HTTP 出站  把本机或局域网里别的内核当上游"
    echo
    ui_sec "整理"
    ui_menu 7 "分组管理            新建 / 改名 / 整组删除"
    ui_menu 8 "删除节点"
    ui_menu 9 "浏览器拨号          逐节点开关（省内存）"
    ui_menu 0 "返回"
    echo
    ui_hint "面板里也能做同样的事: xbd panel（地址与令牌）"
    printf "  %s请选择%s: " "$C_B" "$C_0"
    read -r c || return 0
    case "$c" in
      1) xbd node list ;;
      2) _mmenu_use ;;
      3) xbd node latency ;;
      4) xbd node add ;;
      5) _mmenu_sub_add ;;
      6) xbd node simple ;;
      7) _mmenu_group ;;
      8) _mmenu_del ;;
      9) _mmenu_browser ;;
      0|"") return 0 ;;
      *) ui_invalid "$c" ;;
    esac
    _mmenu_pause
  done
}

_mmenu_sub_add() {
  local url name
  printf '\n  订阅地址: '; read -r url || return 0
  [ -n "$url" ] || { printf '  已取消\n'; return 0; }
  printf '  组名 (留空则按域名自动命名): '; read -r name || name=""
  # 组名必须往下传 —— 漏了的话面板上填的名字静默失效, 节点改按名字推断出别的组
  xbd node sub "$url" "$name"
}

_mmenu_use() {
  local c
  printf '\n'
  xbd node list
  read -r -p "  切换到哪个节点 (编号/名称, 回车取消): " c || return 0
  [ -n "$c" ] || { printf '  已取消\n'; return 0; }
  xbd node use "$c"
}

_mmenu_del() {
  local c
  printf '\n'
  xbd node list
  read -r -p "  删除哪个节点 (编号/名称, 回车取消): " c || return 0
  [ -n "$c" ] || { printf '  已取消\n'; return 0; }
  printf '  确认删除 %s ? [y/N] ' "$c"; read -r a || return 0
  [ "$a" = "y" ] || [ "$a" = "Y" ] || { printf '  已取消\n'; return 0; }
  xbd node remove "$c"
}

# Browser Dialer 逐节点开关。
#
# 为什么放在节点菜单里而不是做成全局开关:
# Browser Dialer 是**每个节点各自的属性**。只有 xhttp/websocket + 域名 +
# 非 REALITY 的节点能走浏览器转发；hysteria/trojan/raw-tcp 这些由 Xray 自己
# 完成 TLS，跟浏览器无关。
#
# 做成全局开关的后果是：切到一个不需要浏览器的节点，浏览器还开着，白占
# 一份 Chromium 的内存（实测 ~180MB）。所以这里的语义是**跟着节点走**，
# 而 Chromium 本身在"当前节点不用浏览器"时会自动停掉释放内存。
#
# 三态：
#   默认  auto —— 协议支持就用，不支持就不用（推荐）
#   浏览器 on   —— 强制用（协议不支持时会拒绝并说明原因）
#   原生  off  —— 强制不用，省内存，节点仍完全可用
_mmenu_browser() {
  local c
  while :; do
    echo
    ui_title "浏览器拨号 (Browser Dialer)"
    printf '  只有 xhttp/websocket 且非 REALITY 的节点能走浏览器转发。\n'
    printf '  选「原生」可省下 Chromium 的内存，节点仍然完全可用。\n'
    printf -- '----------------------\n'
    _xbd_browser_table
    printf -- '----------------------\n'
    ui_menu 1 "逐个切换开关"
    ui_menu 2 "当前节点：切到「浏览器 / 原生 / 默认」"
    ui_menu 3 "把所有支持浏览器的节点设为「浏览器」"
    ui_menu 4 "把所有节点设为「原生」（最省内存）"
    ui_menu 0 "返回"
    printf -- '----------------------\n'
    printf "  %s请选择%s: " "$C_B" "$C_0"
    read -r c || return 0
    case "$c" in
      1) _xbd_browser_pick ;;
      2)
         local cur_name
         cur_name=$(readlink -f "$XBD_NODES/current" 2>/dev/null | xargs -r basename)
         [ -n "$cur_name" ] || { warn "还没有当前节点"; continue; }
         printf '\n  当前节点: %s\n' "$cur_name"
         printf '  设置为 [b=浏览器 / n=原生 / a=默认]: '
         local v; read -r v || return 0
         case "$v" in
           b|B) xbd node browser "$cur_name" on ;;
           n|N) xbd node browser "$cur_name" off ;;
           a|A|"") xbd node browser "$cur_name" auto ;;
           *) warn "没听懂，输入 b / n / a" ;;
         esac
         ;;
      3) _xbd_browser_bulk on ;;
      4) _xbd_browser_bulk off ;;
      0) return 0 ;;
    esac
  done
}

# 打印所有节点 + 浏览器能力 + 当前设置。
# 不支持的节点也要列出来 —— 用户需要知道"为什么这个没有开关"，
# 而不是发现列表里少了几个节点以为没导入成功。
_xbd_browser_table() {
  local f name can want cur
  printf '  %-34s %-9s %-8s %s\n' "节点" "可浏览器" "当前" "传输/协议"
  for f in "$XBD_NODES"/node-*.json; do
    [ -e "$f" ] || continue
    name=$(basename "$f" .json)
    [ "$name" = "current" ] && continue
    # 原来这里写成 `[ ... ] &` —— 那个 & 把整个 test 丢进后台, 于是它不再是
    # 条件表达式, 而是一个后台作业, 退出码也不参与判断。xbd 顶部有
    # `set -euo pipefail`, 非当前节点的 test 返回 1, 整个菜单当场被杀:
    # 节点表能打印(那是上一个循环的输出, 已经写出去了), 但后面的选项行
    # 一行都没打出来。症状是"进得去、看得见列表、就是没法操作"。
    # XBD_NODES 未定义时 readlink -f "$XBD_NODES/current" 会去解析 "/current",
    # 失败返回空 —— 于是它和每个节点的路径都不相等(正常) 或都"相等"(另一侧
    # 也是空时), 于是每个节点都被标成当前。读不到就当没有当前节点, 别猜。
    # 这一段两次踩坑, 都是 set -e 干的:
    #
    #   1) `[ ... ] &` —— 把 test 丢进后台, 退出码不参与判断, 非当前节点的
    #      test 返回 1, 整个菜单当场被杀。
    #   2) `[ -n "${XBD_NODES:-}" ] && _cur_real=...` —— 当 XBD_NODES 为空
    #      时, `[ -n ]` 返回 1, 而它是 && 链的**最后一个命令**, 于是整条
    #      语句返回 1, set -e 照样把脚本杀掉。
    #
    # 所以这里不用 && 串联任何 test, 全部写成 if 的 then 分支 ——
    # if 里的条件返回非 0 是正常控制流, 不会触发 errexit。
    cur=""
    local _cur_real=""
    if [ -n "${XBD_NODES:-}" ]; then
      _cur_real=$(readlink -f "$XBD_NODES/current" 2>/dev/null || true)
    fi
    if [ -n "$_cur_real" ] && [ "$_cur_real" = "$(readlink -f "$f" 2>/dev/null)" ]; then
      cur=" *"
    fi
    # ★ `|| true` 不能省。compat.py json 在"Xray 与浏览器都用不了"时**退出码
    #   为 1**（有效结论，不是失败），而 xbd 顶部是 `set -euo pipefail` ——
    #   管道里一个命令非零整条就非零，这个赋值会把整个菜单当场杀掉。
    #   症状：表格打得出来、选项一行不出、rc=1、stderr 为空。
    #   只要节点列表里**有任意一个**两模式都用不了的节点就会触发。
    can=$(python3 "$XBD_LIBDIR/compat.py" json "$f" 2>/dev/null \
          | python3 -c 'import sys,json
try:
    d=json.load(sys.stdin)
    print("是" if d.get("can_use_dialer") else "否")
except Exception:
    print("?")' 2>/dev/null || true)
    want=$(python3 -c '
import json,sys
try:
    v=json.load(open(sys.argv[1])).get("use_browser", None)
    print({True:"浏览器", False:"原生", None:"默认"}[v] if v is None or isinstance(v,bool) else "默认")
except Exception:
    print("?")' "$f" 2>/dev/null)
    local info
    info=$(python3 -c '
import json,sys
try:
    d=json.load(open(sys.argv[1]))
    print("%s/%s" % (d.get("transport") or "-", d.get("protocol") or "-"))
except Exception:
    print("-")' "$f" 2>/dev/null)
    printf '  %-34s %-9s %-8s %s\n' "${name}${cur}" "$can" "$want" "$info"
  done
}

# 逐个选：列出来 → 输入编号 → 选值
_xbd_browser_pick() {
  local idx=0 f name pick
  printf '\n'
  for f in "$XBD_NODES"/node-*.json; do
    [ -e "$f" ] || continue
    name=$(basename "$f" .json)
    [ "$name" = "current" ] && continue
    idx=$((idx+1))
    local can want
    # `|| true` 见上面 _xbd_browser_table 里的说明（compat.py 退出码 1 是结论）
    can=$(python3 "$XBD_LIBDIR/compat.py" json "$f" 2>/dev/null \
          | python3 -c 'import sys,json
try:
    print("是" if json.load(sys.stdin).get("can_use_dialer") else "否")
except Exception:
    print("?")' 2>/dev/null || true)
    want=$(python3 -c '
import json,sys
try:
    v=json.load(open(sys.argv[1])).get("use_browser", None)
    print({True:"浏览器", False:"原生", None:"默认"}[v] if v is None or isinstance(v,bool) else "默认")
except Exception:
    print("?")' "$f" 2>/dev/null)
    printf '  %2d) %-32s 可浏览器=%-3s 当前=%s\n' "$idx" "$name" "$can" "$want"
  done
  [ "$idx" -eq 0 ] && { warn "还没有节点"; return 0; }
  printf '\n  编号 (直接回车取消): '
  read -r pick || return 0
  [ -n "$pick" ] || return 0
  case "$pick" in
    ''|*[!0-9]*) warn "编号不对"; return 0 ;;
  esac
  [ "$pick" -ge 1 ] && [ "$pick" -le "$idx" ] || { warn "编号超出范围"; return 0; }

  local target
  target=$(ls "$XBD_NODES"/node-*.json 2>/dev/null | grep -v '/current$' | sed -n "${pick}p")
  [ -n "$target" ] || { warn "找不到节点"; return 0; }
  printf '\n  %s → [b=浏览器 / n=原生 / a=默认]: ' "$(basename "$target")"
  local v; read -r v || return 0
  case "$v" in
    b|B) xbd node browser "$target" on ;;
    n|N) xbd node browser "$target" off ;;
    a|A|"") xbd node browser "$target" auto ;;
    *) warn "没听懂，输入 b / n / a" ;;
  esac
}

# 批量设置。只改**协议支持浏览器**的节点 —— 给 hysteria 设成"浏览器"
# 没有意义，cmd_node_browser 会拒绝，不如在这里就不去碰。
_xbd_browser_bulk() {
  local v="$1" f name n=0 skipped=0
  printf '\n'
  for f in "$XBD_NODES"/node-*.json; do
    [ -e "$f" ] || continue
    name=$(basename "$f" .json)
    [ "$name" = "current" ] && continue
    local can
    # `|| true` 见上面 _xbd_browser_table 里的说明（compat.py 退出码 1 是结论）
    can=$(python3 "$XBD_LIBDIR/compat.py" json "$f" 2>/dev/null \
          | python3 -c 'import sys,json
try:
    print("True" if json.load(sys.stdin).get("can_use_dialer") else "False")
except Exception:
    print("False")' 2>/dev/null || true)
    if [ "$can" != "True" ]; then skipped=$((skipped+1)); continue; fi
    _xbd_set_node_browser "$f" "$( [ "$v" = "on" ] && echo true || echo false )"
    n=$((n+1))
  done
  ok "已把 $n 个节点设为「$([ "$v" = on ] && echo 浏览器 || echo 原生)」"
  if [ "$skipped" -gt 0 ]; then
    dim "$skipped 个节点协议不支持浏览器拨号，已跳过（它们本来就不用浏览器）"
  fi
  # 当前节点改了的话要重启才生效
  if _xbd_node_needs_dialer; then
    info "正在重启 Xray 让设置生效…"
    systemctl restart "$XBD_U_XRAY" 2>/dev/null || true
    sleep 4
    if _xbd_node_needs_dialer; then
      unit_active "$XBD_U_CHROMIUM" || xbd_dialer_on || warn "Chromium 启动失败，可手动执行: xbd dialer on"
    else
      unit_active "$XBD_U_CHROMIUM" && xbd_dialer_off || true
    fi
  fi
}

_mmenu_group() {
  local c
  while :; do
    echo
    ui_title "分组管理"
    python3 "$XBD_LIBDIR/subs.py" list "$XBD_PREFIX" 2>/dev/null | sed 's/^/  /' || printf '  (暂无分组)\n'
    printf -- '----------------------\n'
    ui_menu 1 "新建分组"
    ui_menu 2 "整组删除 (连节点一起删)"
    ui_menu 0 "返回"
    printf -- '----------------------\n'
    printf "  %s请选择%s: " "$C_B" "$C_0"
    read -r c || return 0
    case "$c" in
      1)
        local n
        read -r -p "  新分组名称: " n || return 0
        [ -n "$n" ] || { printf '  已取消\n'; continue; }
        python3 "$XBD_LIBDIR/subs.py" add "$XBD_PREFIX" "local:1" "$n" >/dev/null 2>&1 \
          && ok "已创建分组「$n」" || err "创建失败"
        ;;
      2)
        local g
        read -r -p "  删除哪个分组 (名称, 回车取消): " g || return 0
        [ -n "$g" ] || continue
        printf '  确认删除分组「%s」及其全部节点 ? [y/N] ' "$g"; read -r a || return 0
        [ "$a" = "y" ] || [ "$a" = "Y" ] || { printf '  已取消\n'; continue; }
        python3 - "$XBD_PREFIX" "$g" <<'PY'
import sys
sys.path.insert(0, __import__("os").environ.get("XBD_LIBDIR","/opt/xray-browser-dialer/lib"))
import subs as S
pre = sys.argv[1]; name = sys.argv[2]
reg = S.load(pre)
gid = next((s["id"] for s in reg["subs"] if s.get("name") == name), None)
if not gid:
    print("  找不到分组: %s" % name); sys.exit(1)
S.drop(pre, gid)
print("  已删除分组「%s」及其节点" % name)
PY
        ;;
      0) return ;;
      *) ui_invalid "$c" ;;
    esac
    _mmenu_pause
  done
}

_mmenu_service() {
  local c
  while :; do
    echo
    ui_title "服务控制"
    printf '  当前: %s\n' "$(systemctl is-active "$XBD_U_XRAY" 2>/dev/null)"
    printf -- '----------------------\n'
    ui_menu 1 "启动"
    ui_menu 2 "停止"
    ui_menu 3 "重启"
    ui_menu 4 "应用配置并重启"
    ui_menu 0 "返回"
    printf -- '----------------------\n'
    printf "  %s请选择%s: " "$C_B" "$C_0"
    read -r c || return 0
    case "$c" in
      1) xbd start ;; 2) xbd stop ;; 3) xbd restart ;; 4) xbd apply ;; 0) return ;;
      *) ui_invalid "$c" ;;
    esac
    _mmenu_pause
  done
}

_mmenu_port() {
  printf '\n'; xbd ports 2>/dev/null || xbd status
  printf '\n'; read -r -p "  改端口执行 xbd port <类型> <值>, 回车返回..." _ || true
}

_mmenu_multi() {
  local c
  while :; do
    echo
    ui_title "多出站"
    xbd multi status
    printf -- '----------------------\n'
    printf '  关: 只有当前节点进配置, 切换节点需要重启 (连接断 1-2 秒)\n'
    printf '      出问题也只有那一个节点坏, 其余不受影响。\n'
    printf '  开: 所有节点常驻一份配置, 切换不断线。\n'
    printf '      但共享一份配置 —— 一个节点构建失败, 整份都过不了校验。\n'
    printf -- '----------------------\n'
    ui_menu 1 "开启"
    ui_menu 2 "关闭"
    ui_menu 0 "返回"
    printf -- '----------------------\n'
    printf "  %s请选择%s: " "$C_B" "$C_0"
    read -r c || return 0
    case "$c" in
      1) xbd multi on ;;
      2) xbd multi off ;;
      0) return ;;
      *) ui_invalid "$c" ;;
    esac
    _mmenu_pause
  done
}

_mmenu_share() {
  local c
  while :; do
    echo
    ui_title "配置分发"
    printf '  让局域网其他设备用一个 URL 拉走全部节点。\n'
    printf -- '----------------------\n'
    ui_menu 1 "开启 (生成链接)"
    ui_menu 2 "列出所有链接"
    ui_menu 3 "停用某条"
    ui_menu 0 "返回"
    printf -- '----------------------\n'
    printf "  %s请选择%s: " "$C_B" "$C_0"
    read -r c || return 0
    case "$c" in
      1) xbd share new ;;
      2) xbd share list ;;
      3)
        local t
        xbd share list
        read -r -p "  停用哪条 (token): " t || return 0
        [ -n "$t" ] || continue
        xbd share off "$t"
        ;;
      0) return ;;
      *) ui_invalid "$c" ;;
    esac
    _mmenu_pause
  done
}

_mmenu_panel() {
  printf '\n'; xbd panel 2>/dev/null || printf '  xbd panel 查看面板地址\n'
  printf '\n'; read -r -p "  回车返回..." _ || true
}

_share_lan_ip() {
  # 复用 ports.detect_lan —— 它对 `ip route get` 的解析是对的。
  #
  # 自己用 awk 写过一版是错的: 输出形如
  #     1.1.1.1 via 107.173.154.1 dev eth0 src 107.173.154.178
  # 里 src 后面才是本机地址, 而 `/src/ {print $NF}` 取到的是下一行 cache 的
  # 最后一个字段 —— 实测得到 "0", 于是分享链接变成 http://0:18190,
  # 拿到链接的人完全不知道该填什么地址。
  python3 -c "
import sys; sys.path.insert(0, '$XBD_LIBDIR')
import ports
print(ports.detect_lan())" 2>/dev/null || printf '127.0.0.1'
}

share_new() {
  need_root
  local host port tok
  host=$(_share_lan_ip)
  # 端口冲突时自动往后找一个，而不是硬编码一个 —— CC 上 10808/10809 已被占用
  # 端口必须现找一个。CC 上 10808/10809 已被 Xray 占着，硬编码一个固定端口
  # 会跟别的服务撞车 —— 而且撞了之后症状是"分享链接打不开"，很难联想到端口。
  port=$(python3 -c "
import sys; sys.path.insert(0, '$XBD_LIBDIR')
import ports
for p in range(18190, 18290):
    if not ports.in_use(p): print(p); break
else:
    print(''); sys.exit(1)") || die "18190-18290 没有可用端口"
  mkdir -p "$XBD_CONF" "$XBD_RUNTIME/share"
  cat > "$XBD_CONF/share.env" <<EOF
# 配置分发服务。局域网设备用这个 URL 拉本客户端的完整节点配置。
SHARE_HOST=$host
SHARE_PORT=$port
SHARE_HEALTH_UNIT=$XBD_U_XRAY
EOF
  tok=$(python3 -c "
import sys, os
sys.path.insert(0, os.path.join('$XBD_PREFIX','lib'))
import share_server as S
t = S.Store.new_token()
S.Store.save(t, {'enabled': True, 'created_at': int(__import__('time').time()),
                 'max_uses': 0, 'used_count': 0})
print(t)")
  ok "已开启配置分发"
  info "  链接: http://$host:$port/share/$tok"
  info "  在手机/笔记本的客户端里填这个地址就能拉走全部节点。"
  info "  停用: xbd share off ${tok:0:8}..."
  # 起来之后必须确认真的在监听, 否则不能把链接交给用户。
  #
  # 端口是现找的, in_use() 判断与实际 bind 之间有竞态 —— 尤其本机上还有别的
  # share_server (mihomo / amneziawg 那边也有), 抢同一个端口是常事。抢不到时
  # 服务起不来, 而用户拿着一个打不开的链接, 根本无从判断是端口撞了还是自己填错。
  # 要么验证通过, 要么明说, 不留一个"看起来配好了"的假象。
  # 换端口前先彻底停掉旧实例。systemctl restart 会等旧进程退出, 但如果旧进程
  # 是脱离 unit 直接起的 (手工跑过、或上一版留下的), 它不会跟着停, 于是两个
  # 进程各占一个端口, share.env 写的是新的、用户却连到旧的 —— 或者反过来。
  # 端口复用前把残留清掉, 比事后猜是谁占了端口省事得多。
  systemctl stop "$XBD_U_SHARE" >/dev/null 2>&1 || true
  pkill -f "$XBD_LIBDIR/share_server.py" >/dev/null 2>&1 || true
  sleep 1
  systemctl enable --now "$XBD_U_SHARE" >/dev/null 2>&1 \
    || systemctl restart "$XBD_U_SHARE" >/dev/null 2>&1 || true
  sleep 1
  if ! ss -tln 2>/dev/null | grep ":$port " >/dev/null; then
    warn "分享服务没起来 —— $host:$port 可能被别的服务抢占了 (本机还有别的 share_server 时常见)"
    info "  换端口重试: xbd share off ${tok:0:8}...  然后重新 xbd share new"
    info "  或直接看日志: journalctl -u $XBD_U_SHARE -n 20"
  fi
}

share_list() {
  python3 - "$XBD_RUNTIME/share" <<'PY'
import json, os, sys, time
d = sys.argv[1]
rows = []
try:
    for n in sorted(os.listdir(d)):
        if not n.endswith(".json"): continue
        try: m = json.load(open(os.path.join(d, n), encoding="utf-8"))
        except Exception: continue
        m["_t"] = n[:-5]; rows.append(m)
except OSError:
    pass
if not rows:
    print("  还没有分享链接。执行 xbd share new 开启。")
    sys.exit(0)
host, port = "", ""
for line in open("/opt/xray-browser-dialer/config/share.env", encoding="utf-8"):
    if line.startswith("SHARE_HOST="): host = line.split("=",1)[1].strip()
    if line.startswith("SHARE_PORT="): port = line.split("=",1)[1].strip()
for m in rows:
    st = "启用" if m.get("enabled") else "已停用"
    mx = m.get("max_uses", 0)
    print("  %s...  %-6s  已用 %d 次%s" % (
        m["_t"][:12], st, m.get("used_count", 0),
        (" / 上限 %d" % mx) if mx else ""))
    print("      http://%s:%s/share/%s" % (host, port, m["_t"]))
PY
}

share_url() {
  local t="${1:-}"
  [ -n "$t" ] || die "用法: xbd share url <token>"
  python3 -c "
import sys, os
sys.path.insert(0, os.path.join('$XBD_PREFIX','lib'))
import share_server as S
m = S.Store.load('$t')
print('  链接不存在: $t' if m is None else '')" 2>/dev/null
  grep -E '^SHARE_(HOST|PORT)=' "$XBD_CONF/share.env" 2>/dev/null | cut -d= -f2 | tr '\n' ':' | \
    sed "s|^|  http://|;s|:$||;s|\$|/$t|"
}

share_off() {
  local t="${1:-}"
  [ -n "$t" ] || die "用法: xbd share off <token>   (xbd share list 看 token)"
  python3 - "$XBD_RUNTIME/share" "$t" <<'PY'
import json, os, sys
d, t = sys.argv[1], sys.argv[2]
p = os.path.join(d, t + ".json")
if not os.path.isfile(p):
    print("  找不到该分享链接"); sys.exit(1)
m = json.load(open(p, encoding="utf-8"))
m["enabled"] = False
json.dump(m, open(p, "w", encoding="utf-8"), ensure_ascii=False)
print("  已停用: %s" % t)
PY
  info "  链接立即失效。节点和代理不受影响。"
}

cmd_share() {
  local op="${1:-list}"
  case "$op" in
    on|new)    share_new ;;
    list|status) share_list ;;
    off|rm)   share_off "${2:-}" ;;
    url)      share_url "${2:-}" ;;
    -h|--help|help)
      info "用法: xbd share <list|new|url|off> [token]"
      info "  new          开启分享, 生成一条带 token 的链接"
      info "  list         列出所有分享链接和已用次数"
      info "  url <token>  打印某条的完整 URL"
      info "  off <token>  停用 (链接立即失效, 节点配置不受影响)" ;;
    *) die "未知操作: $op (xbd share help 看用法)" ;;
  esac
}

cmd_menu() {
  _mmenu
}

# 读运行配置里 direct 出站的 domainStrategy。
# ★ 不能用 grep 取：配置是**带换行的格式化 JSON**，`"tag": "direct"[^}]*}`
#   这种模式跨不了行，永远匹配不到 —— 于是"回读校验"变成空跑，
#   开关看着生效了其实没人验。用真解析。
_xbd_direct_strategy() {
  python3 - "$XBD_RUNTIME/xray-client.json" <<'PY' 2>/dev/null || true
import json, sys
try:
    d = json.load(open(sys.argv[1]))
    for o in d.get("outbounds", []):
        if o.get("tag") == "direct":
            print((o.get("settings") or {}).get("domainStrategy", ""))
            break
except Exception:
    pass
PY
}

cmd_family() {
  local op="${1:-status}"
  case "$op" in
    auto|v4|v6) _xbd_family_set "$op" ;;
    status|"")  _xbd_family_status ;;
    *) die "未知取值: $op（可用 auto | v4 | v6）" ;;
  esac
}

# 地址族开关。为什么要有它：
#   客户端原来是硬编码的 —— direct 出站 UseIPv4、DNS UseIP。双栈机器上
#   如果 v4 不通（或反过来只有 v6 可达），用户没有任何开关可拨，表现是
#   "直连的站点全打不开，走代理的却正常"，很难联想到是地址族的问题。
#   SB 那边有"切换产物地址族"，M 的 hysteria2 也会探测 ipv4/ipv6/dual。
#
# auto 就是历史行为，**不改任何存量用户的解析方式**。
_xbd_family_set() {
  local v="$1"
  [ "$(id -u)" = "0" ] || die "改地址族需要 root"
  mkdir -p "$XBD_CONF"
  printf '# 出站地址族。auto = 直连走 IPv4、DNS 按连通性选（历史行为）\n# v4/v6 = 强制只走该族。双栈机器上某一边不通时才需要改。\nADDR_FAMILY=%s\n' "$v" > "$XBD_FAMILY_ENV"
  case "$v" in
    v4) ok "已强制走 IPv4" ; info "  直连出站与 DNS 都只走 IPv4（UseIPv4）" ;;
    v6) ok "已强制走 IPv6" ; info "  直连出站与 DNS 都只走 IPv6（UseIPv6）" ;;
    *)  ok "已回到 auto"    ; info "  直连走 IPv4，DNS 交给内核按连通性选（历史行为）" ;;
  esac
  [ "$v" = "v6" ] && warn "  目标站点若没有 AAAA 记录会直接解析失败 —— 这是预期行为，不是 bug"

  # 与 cmd_multi 同一套：apply -> 回读校验 -> 重启。
  # 只 apply 不重启的话，开关显示已改、配置也是新的，但跑着的还是旧配置。
  cmd_apply >/dev/null 2>&1 || true   # 它失败会自己 die
  local want now
  case "$v" in v4) want="UseIPv4" ;; v6) want="UseIPv6" ;; *) want="UseIPv4" ;; esac
  now=$(_xbd_direct_strategy)
  if [ -n "$now" ] && [ "$now" != "$want" ]; then
    warn "配置里 direct 出站是 $now，期望 $want —— 开关已保存但可能没生效"
    warn "xbd apply 看详情"
    return
  fi
  if unit_active "$XBD_U_XRAY"; then
    if xbd restart >/dev/null 2>&1; then
      sleep 1
      ok "Xray 已重启，新地址族生效"
    else
      warn "Xray 重启失败，开关已保存: xbd restart 重试"
    fi
  fi
}

_xbd_family_status() {
  local v now
  v=$(_xbd_family)
  now=$(_xbd_direct_strategy)
  case "$v" in
    v4) printf '  \033[32m强制 IPv4\033[0m   直连出站与 DNS 都只走 IPv4\n' ;;
    v6) printf '  \033[32m强制 IPv6\033[0m   直连出站与 DNS 都只走 IPv6\n' ;;
    *)  printf '  \033[32mauto\033[0m        直连走 IPv4，DNS 按连通性选（历史行为）\n' ;;
  esac
  [ -n "$now" ] && printf '  运行配置里的 direct 出站: %s\n' "$now"
}

cmd_multi() {
  local op="${1:-status}"
  case "$op" in
    on)   _xbd_multi_set on ;;
    off)  _xbd_multi_set off ;;
    status|"") _xbd_multi_status ;;
    *) die "未知操作: $op (xbd multi status 看当前状态)" ;;
  esac
}

_xbd_multi_set() {
  local v="$1"
  [ "$(id -u)" = "0" ] || die "改多出站开关需要 root"
  mkdir -p "$XBD_CONF"
  printf '# 多出站开关。on = 所有节点常驻一份配置, 切换节点不用重启; off = 单节点。\nMULTI_OUTBOUND=%s\n' "$v" > "$XBD_MULTI_ENV"
  if [ "$v" = "on" ]; then
    ok "已开启多出站"
    info "  切换节点不再需要重启。"
    warn "  所有节点共享一份配置：任何一个节点构建失败，整份配置通不过校验。"
  else
    ok "已关闭多出站，回到单节点"
    info "  切换节点会重启 Xray（连接断 1-2 秒）。"
  fi
  # 必须 apply **并重启** 才能生效, 只 apply 不够。
  #
  # cmd_apply 只重新生成配置, 不会碰运行中的实例。所以只 apply 的话, 开关显示
  # 已开启、配置里 balancer 也有了, 但跑着的还是旧配置 —— 用户切换节点时照样要
  # 重启, 而他刚点的"开启不断线切换"。这种"看着开了、实际没开"最难解释。
  #
  # 面板那条路径 (act_multi_set) 走的是 xbd restart, 是一致的。
  # 判据用"配置文件有没有变成期望的样子", 不用 xbd apply 的退出码 ——
  # cmd_apply 成功时没有显式 return 0, 返回的是最后一条命令的退出码, 不可靠。
  cmd_apply >/dev/null 2>&1 || true   # 它失败会自己 die, 走不到这里
  local want_bal now_bal
  want_bal=$([ "$v" = "on" ] && echo 1 || echo 0)
  # 这里有两个坑, 少处理一个都会静默失败:
  #
  # 1) grep -c 没匹配时退出码是 1。脚本跑在 set -euo pipefail 下, 裸写会让
  #    整条管道返回 1, set -e 当场退出脚本 —— 而我们恰恰要频繁问"有没有
  #    balancer"(单节点模式答案就是 0)。所以 || true 必须有。
  # 2) 命中多个文件时 grep -c 会逐文件输出一串数字, 要 head -1 取第一个。
  now_bal=$(grep -c 'balancerTag' "$XBD_RUNTIME/xray-client.json" 2>/dev/null | awk 'NR==1' || true)
  now_bal=${now_bal:-0}
  if [ "$want_bal" != "$now_bal" ]; then
    warn "配置生成不符合预期（期望 balancerTag $want_bal，实际 $now_bal）"
    warn "开关已保存但还没生效: xbd apply 看详情"
    return
  fi
  if unit_active "$XBD_U_XRAY"; then
    if _xbd_sync_xray_with_node force; then
      sleep 1
      local actual
      actual=$(cat "$XBD_RUNTIME/multi.actual" 2>/dev/null || echo "")
      [ "$actual" = "$([ "$v" = on ] && echo multi || echo single)" ] \
        || warn "服务已重启，但实际模式与开关不一致 —— xbd multi status 看详情"
    else
      warn "Xray 重启失败，开关已保存: xbd restart 重试"
    fi
  fi
}

_xbd_multi_status() {
  local m actual
  m=$(_xbd_multi_mode)
  actual=$(cat "$XBD_RUNTIME/multi.actual" 2>/dev/null || echo "")
  if [ "$m" = "on" ]; then
    ok "多出站已开启  所有节点常驻一份配置，切换节点不用重启"
    # 同样要 || true: 单节点模式下匹配数不为 0, 但文件不存在时 grep 会返回 1,
    # 在 pipefail 下配合 set -e 会让整个 status 命令失败。
    printf '  出站数: %s\n' "$(grep -c '"tag":' "$XBD_RUNTIME/xray-client.json" 2>/dev/null | awk 'NR==1' || true)"
  else
    printf '  %s单节点模式%s  当前配置只有当前节点，切换节点需要重启\n' "$C_B" "$C_0"
  fi
  # 开关说开、实际却是单节点（或反过来），是会出现的不一致状态。必须报出来：
  # 用户看到"已开启"却发现切换仍然要重启，第一反应是"面板坏了"。
  if [ "$m" = "on" ] && [ "$actual" != "multi" ]; then
    warn "开关是开的，但实际跑的是单节点 —— 执行 xbd apply 重启后才会生效"
  elif [ "$m" = "off" ] && [ "$actual" = "multi" ]; then
    warn "开关是关的，但实际跑的是多出站 —— 执行 xbd apply 重启后才会生效"
  fi
}

cmd_selftest() {
  local failed=0
  echo "=== 内置自检 ==="
  for m in node compat; do
    printf '  %-10s ' "$m"
    if python3 "$XBD_LIBDIR/$m.py" selftest >/tmp/.xbd_st 2>&1; then
      echo "PASS"; tail -1 /tmp/.xbd_st | sed 's/^/             /'
    else
      echo "FAIL"; cat /tmp/.xbd_st | sed 's/^/             /'; failed=$((failed+1))
    fi
  done
  printf '  %-10s ' "genconfig"
  if python3 "$XBD_LIBDIR/genconfig.py" --node "$XBD_LIBDIR/../nodes/current" \
      --output /tmp/.xbd_tc.json --mode normal --logs /tmp >/dev/null 2>&1; then
    echo "PASS"
  else
    echo "SKIP（还没有节点）"
  fi
  rm -f /tmp/.xbd_st /tmp/.xbd_tc.json

  # 架构自检：断言"唯一实例 + 两个入口 + 按节点决定是否走浏览器"这套模型真的成立。
  # 双实例/双端口一旦回归，界面上看不出来，只有这里能发现。
  printf '  %-10s ' "arch"
  if [ -x "$XBD_PREFIX/tools/selftest-arch.sh" ]; then
    if bash "$XBD_PREFIX/tools/selftest-arch.sh" >/tmp/.xbd_arch 2>&1; then
      echo "PASS"; grep -E '架构自检: PASS' /tmp/.xbd_arch | sed 's/^/             /'
    else
      echo "FAIL"; grep -E '✗|架构自检: FAIL' /tmp/.xbd_arch | sed 's/^/             /'; failed=$((failed+1))
    fi
  else
    echo "SKIP（缺少 tools/selftest-arch.sh）"
  fi
  # 分组 / 多出站自检。重点是那条"单节点配置逐字节不变" —— Browser Dialer 走的
  # 就是单节点路径，多出站改造动的是同一个文件，这条断言是不让它被改掉的护栏。
  printf '  %-10s ' "groups"
  if [ -f "$XBD_PREFIX/tools/selftest-groups.py" ]; then
    if python3 "$XBD_PREFIX/tools/selftest-groups.py" \
         --lib "$XBD_LIBDIR" >/tmp/.xbd_grp 2>&1; then
      echo "PASS"; grep -E '结果:' /tmp/.xbd_grp | sed 's/^/             /'
    else
      echo "FAIL"; grep -E '✗|结果:' /tmp/.xbd_grp | sed 's/^/             /'; failed=$((failed+1))
    fi
  else
    echo "SKIP（缺少 tools/selftest-groups.py）"
  fi
  rm -f /tmp/.xbd_grp
  echo
  [ "$failed" -eq 0 ] && { echo "自检: PASS"; return 0; } || { echo "自检: $failed 项失败"; return 1; }
}
