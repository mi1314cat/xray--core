#!/usr/bin/env python3
"""导入分流：剔除 Xray 内核不支持的协议，并对重复节点去重。

为什么要有这一步 —— 用户一次可能贴一大段订阅，里面混着：
  * Xray 内核根本不支持的协议（tuic / hysteria v1 / 其它内核专属协议）；
  * 重复条目（订阅里很常见，同一份导入两次列表就翻倍，实测 9 个变 17 个）。

以前是一股脑儿落盘、只打标签，列表被灌满还得自己一个个看。现在默认：
不支持的跳过、重复的跳过（既与本批内比，也与已落盘的比），最后汇总说明跳了什么。

用法:
    nodefilter.py <解析出的节点数组.json> <lib目录> <是否保留不支持:0|1> <nodes目录>
输出:
    stdout  = 每行一个 JSON（要导入的节点）
    /tmp/.xbd_updated.json = [[名字, 已有文件路径], ...] 参数变化、已原地更新
    /tmp/.xbd_skipped.json = [[名字, 原因, 已有节点路径(可能为空)], ...] 供调用方处理
"""
from __future__ import annotations

import importlib.util
import json
import os
import sys

SKIPPED_PATH = "/tmp/.xbd_skipped.json"
UPDATED_PATH = "/tmp/.xbd_updated.json"


def load_compat(libdir: str):
    spec = importlib.util.spec_from_file_location("c", os.path.join(libdir, "compat.py"))
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def sig(n: dict) -> str:
    """连接参数签名：用来判"同一个节点，参数是否变了"。

    ident() 只回答"是不是同一个节点"（协议/地址/端口/凭据/传输）；
    但同一个节点的 path、security、sni、REALITY 公钥、mode、下行设置
    都可能变 —— 2026-10-17 前置 REALITY 修复后，服务端把 security 从
    tls 改成 reality，客户端按 ident 判重直接跳过，旧节点永远不更新，
    表现是"订阅刷新成功、节点还是连不上"。签名把这些字段都算进来。

    刻意排除：source（来源文件名，会变）、pinned_cert_sha256（本机探针）、
    raw/raw_params（原始链接文本，等价信息已在结构化字段里）。
    """
    skip = {"source", "pinned_cert_sha256", "raw", "raw_params"}
    return json.dumps({k: v for k, v in n.items() if k not in skip},
                      ensure_ascii=False, sort_keys=True, default=str)


def ident(n: dict) -> str:
    """连接身份：协议 + 地址 + 端口 + 凭据 + 传输。

    用它判重，不看名字 —— 同一个节点在不同订阅里名字经常不一样，
    而连接参数才是"是不是同一个节点"的唯一依据。
    """
    cred = n.get("uuid") or n.get("password") or ""
    return "|".join(str(x) for x in (n.get("protocol"), n.get("address"),
                                     n.get("port"), cred, n.get("transport")))


def main(argv) -> int:
    if len(argv) < 5:
        print("用法: nodefilter.py <nodes.json> <libdir> <keep:0|1> <nodesdir>", file=sys.stderr)
        return 2
    src, libdir, keep, nodesdir = argv[1], argv[2], argv[3] == "1", argv[4]
    m = load_compat(libdir)

    seen: set = set()
    seen_path: dict = {}
    if os.path.isdir(nodesdir):
        for f in sorted(os.listdir(nodesdir)):
            if not (f.startswith("node-") and f.endswith(".json")):
                continue
            try:
                k = ident(json.load(open(os.path.join(nodesdir, f), encoding="utf-8")))
                seen.add(k)
                seen_path[k] = os.path.join(nodesdir, f)
            except Exception:
                pass          # 坏文件不该阻断整批导入

    skipped = []
    updated = []
    try:
        incoming = json.load(open(src, encoding="utf-8"))
    except (OSError, ValueError) as exc:
        print(f"读取解析结果失败: {exc}", file=sys.stderr)
        return 2

    for n in incoming:
        caps = m.check_all(n)
        if not caps.get("can_use_xray") and not keep:
            # ★ 原因必须来自**判定本身**，不能一律写"内核不支持该协议"。
            #   实测（E2E 分享订阅 5 个只导入 4 个）：trojan+REALITY 只是链接里的
            #   pbk/sid 没被解析出来（见 node.py: parse_trojan），旧文案却告诉用户
            #   "Xray 内核不支持该协议（trojan）"—— 内核恰恰原生支持 trojan，
            #   照那句话排查等于南辕北辙，换内核也解决不了。
            #   真实原因由 compat.blocking_reason() 从判定结果里取。
            reason = ""
            try:
                reason = m.blocking_reason(n, caps)
            except Exception:                                     # noqa: BLE001
                reason = ""
            reason = reason or f"Xray 内核不支持该节点（{n.get('protocol')}）"
            skipped.append((n.get("name"), reason))
            continue
        k = ident(n)
        if k in seen:
            path = seen_path.get(k, "")
            # ---- 同一个节点、参数变了 → 原地**更新**，不能只报"重复" ----
            # 不更新的话，服务端改了 path/security/密钥之后，客户端永远
            # 拿着旧参数（实测：前置 REALITY 节点修好后，刷新订阅仍然连不上）。
            old = None
            if path:
                try:
                    old = json.load(open(path, encoding="utf-8"))
                except Exception:
                    old = None
            if old is not None and sig(old) != sig(n):
                merged = {**old, **n}
                try:
                    tmp = path + ".tmp"
                    with open(tmp, "w", encoding="utf-8") as fh:
                        json.dump(merged, fh, ensure_ascii=False, indent=1)
                    os.replace(tmp, path)
                    updated.append((n.get("name"), path))
                    continue
                except OSError:
                    pass          # 写不进去就走"重复"分支，别让导入整个失败
            # 第三条是『已有那份』的路径：重复导入时调用方要用它去补/修指纹。
            # 为什么必须给路径：实测用户重新导入一次以为能修好，但去重直接跳过，
            # 那份没指纹的坏节点根本没人碰，于是『再次导入还是不行』。
            skipped.append((n.get("name"),
                            "与已有节点或本批前面的条目重复（同协议/地址/端口/凭据）",
                            path))
            continue
        seen.add(k)
        print(json.dumps(n, ensure_ascii=False))

    try:
        json.dump(skipped, open(SKIPPED_PATH, "w", encoding="utf-8"), ensure_ascii=False)
    except OSError:
        pass
    try:
        json.dump(updated, open(UPDATED_PATH, "w", encoding="utf-8"), ensure_ascii=False)
    except OSError:
        pass
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
